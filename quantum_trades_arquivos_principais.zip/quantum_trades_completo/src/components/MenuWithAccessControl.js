/**
 * MenuWithAccessControl.js
 * Componente de menu lateral com controle de acesso por nível de usuário
 */

import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Box,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
  Typography
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import DashboardIcon from '@mui/icons-material/Dashboard';
import ShowChartIcon from '@mui/icons-material/ShowChart';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import DescriptionIcon from '@mui/icons-material/Description';
import SettingsIcon from '@mui/icons-material/Settings';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import StarIcon from '@mui/icons-material/Star';
import { useAuth } from '../contexts/AuthContext';
import { ACCESS_LEVELS } from '../utils/UserProfileStructure';
import AccessControl from './AccessControl';

/**
 * Componente de menu lateral com controle de acesso
 * 
 * @returns {React.ReactElement} Menu lateral
 */
const MenuWithAccessControl = () => {
  const theme = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // Itens do menu com controle de acesso
  const menuItems = [
    {
      text: 'Dashboard',
      icon: <DashboardIcon />,
      path: '/dashboard',
      requiredLevel: ACCESS_LEVELS.BASIC
    },
    {
      text: 'Portfólio',
      icon: <AccountBalanceWalletIcon />,
      path: '/portfolio',
      requiredLevel: ACCESS_LEVELS.BASIC
    },
    {
      text: 'Ordens',
      icon: <ShowChartIcon />,
      path: '/orders',
      requiredLevel: ACCESS_LEVELS.PREMIUM
    },
    {
      text: 'Research',
      icon: <DescriptionIcon />,
      path: '/research',
      requiredLevel: ACCESS_LEVELS.PREMIUM
    },
    {
      text: 'Administração',
      icon: <AdminPanelSettingsIcon />,
      path: '/admin',
      requiredLevel: ACCESS_LEVELS.ADMIN
    },
    {
      text: 'Configurações',
      icon: <SettingsIcon />,
      path: '/settings',
      requiredLevel: ACCESS_LEVELS.BASIC
    }
  ];
  
  const handleNavigate = (path) => {
    navigate(path);
  };
  
  return (
    <Box sx={{ width: '100%' }}>
      {user && (
        <Box sx={{ p: 2 }}>
          <Typography variant="subtitle1" fontWeight="bold">
            {user.name}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
            <Typography variant="body2" color="text.secondary">
              Plano: 
            </Typography>
            <Box 
              sx={{ 
                display: 'flex', 
                alignItems: 'center', 
                ml: 1,
                backgroundColor: user.level >= ACCESS_LEVELS.PREMIUM ? 'rgba(212, 175, 55, 0.1)' : 'transparent',
                px: 1,
                py: 0.2,
                borderRadius: 1
              }}
            >
              {user.level >= ACCESS_LEVELS.PREMIUM && (
                <StarIcon sx={{ fontSize: 14, color: '#D4AF37', mr: 0.5 }} />
              )}
              <Typography 
                variant="body2" 
                color={user.level >= ACCESS_LEVELS.PREMIUM ? '#D4AF37' : 'text.secondary'}
                fontWeight={user.level >= ACCESS_LEVELS.PREMIUM ? 'bold' : 'normal'}
              >
                {user.level === ACCESS_LEVELS.ADMIN ? 'Administrador' : 
                  user.level === ACCESS_LEVELS.PREMIUM ? 'Premium' : 'Básico'}
              </Typography>
            </Box>
          </Box>
        </Box>
      )}
      
      <Divider />
      
      <List>
        {menuItems.map((item) => (
          <AccessControl 
            key={item.text} 
            requiredLevel={item.requiredLevel}
            hideCompletely={false}
          >
            <ListItem disablePadding>
              <ListItemButton
                selected={location.pathname === item.path}
                onClick={() => handleNavigate(item.path)}
                sx={{
                  '&.Mui-selected': {
                    backgroundColor: 'rgba(16, 38, 61, 0.08)',
                    borderRight: `3px solid ${theme.palette.primary.main}`,
                    '&:hover': {
                      backgroundColor: 'rgba(16, 38, 61, 0.12)',
                    }
                  }
                }}
              >
                <ListItemIcon 
                  sx={{ 
                    color: location.pathname === item.path ? 
                      theme.palette.primary.main : 'inherit',
                    minWidth: 40
                  }}
                >
                  {item.icon}
                </ListItemIcon>
                <ListItemText 
                  primary={item.text} 
                  primaryTypographyProps={{
                    fontWeight: location.pathname === item.path ? 'bold' : 'normal'
                  }}
                />
                {item.requiredLevel > ACCESS_LEVELS.BASIC && (
                  <Box 
                    sx={{ 
                      ml: 1,
                      backgroundColor: item.requiredLevel === ACCESS_LEVELS.ADMIN ? 
                        'rgba(255, 86, 48, 0.1)' : 'rgba(212, 175, 55, 0.1)',
                      px: 1,
                      py: 0.2,
                      borderRadius: 1,
                      display: 'flex',
                      alignItems: 'center'
                    }}
                  >
                    {item.requiredLevel === ACCESS_LEVELS.PREMIUM && (
                      <StarIcon sx={{ fontSize: 12, color: '#D4AF37', mr: 0.5 }} />
                    )}
                    <Typography 
                      variant="caption" 
                      sx={{ 
                        fontSize: '0.65rem',
                        color: item.requiredLevel === ACCESS_LEVELS.ADMIN ? 
                          'error.main' : '#D4AF37',
                        fontWeight: 'bold'
                      }}
                    >
                      {item.requiredLevel === ACCESS_LEVELS.ADMIN ? 'ADMIN' : 'PREMIUM'}
                    </Typography>
                  </Box>
                )}
              </ListItemButton>
            </ListItem>
          </AccessControl>
        ))}
      </List>
      
      <Divider />
      
      <AccessControl requiredLevel={ACCESS_LEVELS.BASIC} fallback={null}>
        <Box sx={{ p: 2, mt: 2 }}>
          {user && user.level < ACCESS_LEVELS.PREMIUM && (
            <Box 
              sx={{ 
                p: 2, 
                backgroundColor: 'rgba(212, 175, 55, 0.1)', 
                borderRadius: 2,
                border: '1px solid rgba(212, 175, 55, 0.3)'
              }}
            >
              <Typography variant="subtitle2" sx={{ color: '#D4AF37', mb: 1 }}>
                Faça upgrade para Premium
              </Typography>
              <Typography variant="body2" sx={{ mb: 1.5, fontSize: '0.8rem' }}>
                Acesse recursos exclusivos como emissão de ordens e análises avançadas.
              </Typography>
              <Box 
                sx={{ 
                  backgroundColor: '#D4AF37',
                  color: 'white',
                  textAlign: 'center',
                  py: 0.5,
                  borderRadius: 1,
                  cursor: 'pointer',
                  '&:hover': {
                    backgroundColor: '#c4a030'
                  }
                }}
                onClick={() => navigate('/upgrade')}
              >
                <Typography variant="caption" fontWeight="bold">
                  UPGRADE
                </Typography>
              </Box>
            </Box>
          )}
        </Box>
      </AccessControl>
    </Box>
  );
};

export default MenuWithAccessControl;
