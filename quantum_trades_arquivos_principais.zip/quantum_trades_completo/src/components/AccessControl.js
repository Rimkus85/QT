/**
 * AccessControl.js
 * Componente para controle de acesso baseado em nível de usuário
 * Permite restringir conteúdo e funcionalidades com base no nível de permissão
 */

import React from 'react';
import PropTypes from 'prop-types';
import { useAuth } from '../contexts/AuthContext';

/**
 * Componente de controle de acesso que renderiza conteúdo com base no nível de permissão do usuário
 * 
 * @param {Object} props - Propriedades do componente
 * @param {React.ReactNode} props.children - Conteúdo a ser renderizado se o usuário tiver permissão
 * @param {number} props.requiredLevel - Nível de acesso necessário para visualizar o conteúdo
 * @param {React.ReactNode} props.fallback - Conteúdo alternativo a ser renderizado se o usuário não tiver permissão
 * @param {boolean} props.hideCompletely - Se verdadeiro, não renderiza nada quando o usuário não tem permissão
 * @returns {React.ReactElement|null} Conteúdo renderizado ou null
 */
const AccessControl = ({ 
  children, 
  requiredLevel = 1, 
  fallback = null, 
  hideCompletely = false 
}) => {
  const { isAuthenticated, hasPermission } = useAuth();
  
  // Se o usuário não estiver autenticado, não renderiza nada ou renderiza o fallback
  if (!isAuthenticated) {
    return hideCompletely ? null : fallback;
  }
  
  // Verifica se o usuário tem o nível de permissão necessário
  const hasAccess = hasPermission(requiredLevel);
  
  // Renderiza o conteúdo apropriado com base na permissão
  if (hasAccess) {
    return <>{children}</>;
  } else {
    return hideCompletely ? null : fallback;
  }
};

AccessControl.propTypes = {
  children: PropTypes.node.isRequired,
  requiredLevel: PropTypes.number,
  fallback: PropTypes.node,
  hideCompletely: PropTypes.bool
};

export default AccessControl;
