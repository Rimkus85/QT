/**
 * QuantumLogo.js
 * Componente do logo oficial do Quantum Trades usando o arquivo PNG fornecido pelo usuário
 * Tamanho reduzido para 50% conforme solicitado
 */

import React from 'react';
import { Box } from '@mui/material';
import logoImage from '../assets/images/quantum_logo.png';

const QuantumLogo = ({ width = 100, height = 100 }) => {
  return (
    <Box
      sx={{
        width: width,
        height: height,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'transparent',
      }}
    >
      <img 
        src={logoImage} 
        alt="Quantum Trades Logo" 
        style={{ 
          width: '100%', 
          height: '100%', 
          objectFit: 'contain',
          backgroundColor: 'transparent'
        }} 
      />
    </Box>
  );
};

export default QuantumLogo;
