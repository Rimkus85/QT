/**
 * ForgotPasswordForm.js
 * Componente de formulário para recuperação de senha do Quantum Trades
 */

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Box, 
  TextField, 
  Button, 
  Typography, 
  Alert, 
  Paper,
  CircularProgress
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

/**
 * Componente de formulário para recuperação de senha
 * 
 * @returns {React.ReactElement} Formulário de recuperação de senha
 */
const ForgotPasswordForm = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const navigate = useNavigate();
  
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [emailSent, setEmailSent] = useState(false);
  const [error, setError] = useState('');
  
  // Validação de formato de e-mail
  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validação do campo de e-mail
    if (!email) {
      setError('Por favor, informe seu e-mail.');
      return;
    }
    
    // Validação do formato de e-mail
    if (!isValidEmail(email)) {
      setError('Por favor, informe um e-mail válido.');
      return;
    }
    
    setError('');
    setIsSubmitting(true);
    
    // Simulação de envio de e-mail (mock)
    setTimeout(() => {
      setIsSubmitting(false);
      setEmailSent(true);
    }, 1500);
  };
  
  const handleBackToLogin = () => {
    navigate('/login');
  };
  
  return (
    <Paper 
      elevation={3}
      sx={{ 
        p: { xs: 3, sm: 4 },
        width: '100%',
        maxWidth: 450,
        mx: 'auto'
      }}
    >
      {emailSent ? (
        <Box sx={{ textAlign: 'center' }}>
          <Typography variant="h5" component="h1" gutterBottom>
            E-mail enviado!
          </Typography>
          
          <Typography variant="body1" sx={{ mb: 3 }}>
            Enviamos instruções para recuperação de senha para o e-mail {email}.
            Por favor, verifique sua caixa de entrada e siga as instruções.
          </Typography>
          
          <Button
            variant="contained"
            color="primary"
            onClick={handleBackToLogin}
            fullWidth
            sx={{ mt: 2 }}
          >
            Voltar para o login
          </Button>
        </Box>
      ) : (
        <Box component="form" onSubmit={handleSubmit} noValidate>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
            <Button
              startIcon={<ArrowBackIcon />}
              onClick={handleBackToLogin}
              sx={{ mr: 2 }}
            >
              Voltar
            </Button>
            
            <Typography variant="h5" component="h1">
              Recuperar senha
            </Typography>
          </Box>
          
          <Typography variant="body1" sx={{ mb: 3 }}>
            Informe seu e-mail de cadastro para receber instruções de recuperação de senha.
          </Typography>
          
          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}
          
          <TextField
            margin="normal"
            required
            fullWidth
            id="email"
            label="E-mail"
            name="email"
            autoComplete="email"
            autoFocus
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={isSubmitting}
            sx={{ mb: 2 }}
          />
          
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="primary"
            disabled={isSubmitting}
            sx={{ 
              mt: 2, 
              mb: 2,
              py: 1.5,
              backgroundColor: theme.palette.primary.main,
              '&:hover': {
                backgroundColor: theme.palette.primary.dark,
              }
            }}
          >
            {isSubmitting ? (
              <CircularProgress size={24} color="inherit" />
            ) : (
              'Enviar instruções'
            )}
          </Button>
        </Box>
      )}
    </Paper>
  );
};

export default ForgotPasswordForm;
