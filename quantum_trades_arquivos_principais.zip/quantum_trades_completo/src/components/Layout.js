import React from 'react';
import { 
  Box, 
  Drawer, 
  IconButton, 
  List, 
  ListItem, 
  ListItemIcon, 
  ListItemText, 
  Toolbar, 
  Typography, 
  Divider,
  Avatar,
  Menu,
  MenuItem,
  Tooltip,
  AppBar as MuiAppBar,
  useTheme,
  useMediaQuery,
  Badge,
  alpha
} from '@mui/material';
import { styled } from '@mui/material/styles';
import { 
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  ShowChart as ShowChartIcon,
  Send as SendIcon,
  Psychology as PsychologyIcon,
  Settings as SettingsIcon,
  Logout as LogoutIcon,
  Notifications as NotificationsIcon,
  Search,
  ElectricBolt,
  Bolt,
  Flare,
  Whatshot,
  AutoGraph,
  AccountCircle,
  Settings
} from '@mui/icons-material';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { usePremiumTheme } from '../contexts/PremiumThemeContext';
import { motion, AnimatePresence } from 'framer-motion';
import { colors, gradients, customShadows } from '../theme';

const drawerWidth = 280;

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  backgroundImage: 'none',
  backgroundColor: alpha(theme.palette.background.default, 0.8),
  backdropFilter: 'blur(10px)',
  borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
  boxShadow: 'none',
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: theme.spacing(3),
  ...theme.mixins.toolbar,
}));

const Layout = () => {
  const { user, logout } = useAuth();
  const { animations } = usePremiumTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [notificationAnchorEl, setNotificationAnchorEl] = React.useState(null);
  
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
  
  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  
  const handleProfileMenuClose = () => {
    setAnchorEl(null);
  };
  
  const handleNotificationsOpen = (event) => {
    setNotificationAnchorEl(event.currentTarget);
  };
  
  const handleNotificationsClose = () => {
    setNotificationAnchorEl(null);
  };
  
  const handleLogout = () => {
    handleProfileMenuClose();
    logout();
    navigate('/login');
  };
  
  const menuItems = [
    {
      text: 'Dashboard',
      icon: <DashboardIcon />,
      path: '/'
    },
    {
      text: 'Simulador',
      icon: <ShowChartIcon />,
      path: '/simulator'
    },
    {
      text: 'Agente de Execução',
      icon: <SendIcon />,
      path: '/execution'
    },
    {
      text: 'IA Adaptativa',
      icon: <PsychologyIcon />,
      path: '/ai-learning'
    },
    {
      text: 'Configurações',
      icon: <SettingsIcon />,
      path: '/settings'
    }
  ];
  
  const drawer = (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      height: '100%',
      background: `linear-gradient(180deg, ${alpha(colors.black.main, 0.95)} 0%, ${alpha(colors.black.light, 0.95)} 100%)`,
      position: 'relative',
      overflow: 'hidden'
    }}>
      <DrawerHeader>
        <Box sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          flexDirection: 'column',
          position: 'relative',
          zIndex: 1
        }}>
          <Typography 
            variant="h5" 
            component="div" 
            sx={{ 
              fontWeight: 'bold',
              fontFamily: '"Orbitron", sans-serif',
              textTransform: 'uppercase',
              letterSpacing: '0.1em',
              color: colors.gold.main,
              mb: 1,
              fontWeight: 'bold',
              textShadow: `0 0 10px ${alpha(colors.gold.main, 0.7)}`
            }}
            className="gold-text"
          >
            QUANTUM TRADES
          </Typography>
          <Typography 
            variant="caption" 
            sx={{ 
              fontFamily: '"Rajdhani", sans-serif',
              letterSpacing: '0.05em',
              textTransform: 'uppercase',
              color: alpha(colors.gold.main, 0.9)
            }}
          >
            Trading Multi-Mercado
          </Typography>
        </Box>
      </DrawerHeader>
      
      <Divider sx={{ borderColor: 'rgba(255, 255, 255, 0.05)' }} />
      
      <List sx={{ flexGrow: 1, px: 2, py: 1, position: 'relative', zIndex: 1 }}>
        {menuItems.map((item, index) => {
          const isSelected = location.pathname === item.path || 
                            (location.pathname === '/' && item.path === '/dashboard');
          
          return (
            <motion.div
              key={item.text}
              initial={animations && !isMobile ? { x: -20, opacity: 0 } : false}
              animate={animations && !isMobile ? { x: 0, opacity: 1 } : false}
              transition={{ duration: 0.3, delay: 0.1 * index }}
              whileHover={{ 
                x: 5,
                transition: { duration: 0.2 }
              }}
            >
              <ListItem 
                button 
                onClick={() => {
                  navigate(item.path);
                  if (isMobile) setMobileOpen(false);
                }}
                selected={isSelected}
                sx={{
                  borderRadius: 2,
                  mb: 1,
                  position: 'relative',
                  overflow: 'hidden',
                  '&.Mui-selected': {
                    backgroundColor: alpha(colors.gold.main, 0.15),
                    borderLeft: `4px solid ${colors.gold.main}`,
                    pl: 2,
                    '&:hover': {
                      backgroundColor: alpha(colors.gold.main, 0.2),
                    },
                    '&::before': {
                      content: '""',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      background: `linear-gradient(90deg, ${alpha(colors.gold.main, 0.1)} 0%, transparent 100%)`,
                      zIndex: 0
                    }
                  },
                  '&:hover': {
                    backgroundColor: alpha(colors.gold.main, 0.1),
                  },
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
                }}
              >
                <ListItemIcon sx={{ 
                  color: isSelected ? colors.gold.main : alpha(colors.text.primary, 0.7),
                  minWidth: '40px',
                  position: 'relative',
                  zIndex: 1,
                  transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
                }}>
                  {item.icon}
                </ListItemIcon>
                <ListItemText 
                  primary={item.text} 
                  primaryTypographyProps={{ 
                    fontWeight: isSelected ? 600 : 400,
                    fontSize: '0.95rem',
                    fontFamily: '"Rajdhani", sans-serif',
                    letterSpacing: '0.05em',
                    position: 'relative',
                    zIndex: 1,
                    color: isSelected ? colors.gold.main : alpha(colors.text.primary, 0.9),
                    textShadow: isSelected ? `0 0 10px ${alpha(colors.gold.main, 0.3)}` : 'none',
                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
                  }}
                />
                {item.text === 'Agente de Execução' && (
                  <Box 
                    sx={{ 
                      width: 8, 
                      height: 8, 
                      borderRadius: '50%', 
                      bgcolor: colors.success.main,
                      boxShadow: '0 0 10px rgba(0, 230, 118, 0.7)',
                      position: 'relative',
                      zIndex: 1
                    }} 
                  />
                )}
              </ListItem>
            </motion.div>
          );
        })}
      </List>
      
      <Box sx={{ p: 2, position: 'relative', zIndex: 1 }}>
        <Divider sx={{ mb: 2, borderColor: 'rgba(255, 255, 255, 0.05)' }} />
        <Typography 
          variant="caption" 
          color="text.secondary" 
          align="center" 
          display="block"
          sx={{ 
            fontFamily: '"Rajdhani", sans-serif',
            letterSpacing: '0.05em'
          }}
        >
          © {new Date().getFullYear()} Quantum Trades
        </Typography>
        <Typography 
          variant="caption" 
          color="text.secondary" 
          align="center" 
          display="block"
          sx={{ 
            fontFamily: '"Space Mono", monospace',
            letterSpacing: '0.05em'
          }}
        >
          Versão 2.0.0
        </Typography>
      </Box>
      
      {/* Elementos decorativos */}
      <Box 
        sx={{ 
          position: 'absolute', 
          top: 0, 
          right: 0, 
          width: '1px', 
          height: '100%', 
          background: `linear-gradient(to bottom, ${alpha(colors.gold.main, 0.3)}, transparent)`,
          zIndex: 0
        }} 
      />
      <Box 
        sx={{ 
          position: 'absolute', 
          top: 0, 
          left: 0, 
          width: '1px', 
          height: '100%', 
          background: `linear-gradient(to bottom, ${alpha(colors.gold.main, 0.3)}, transparent)`,
          zIndex: 0
        }} 
      />
      <Box 
        sx={{ 
          position: 'absolute', 
          top: '20%', 
          right: '10%', 
          width: '50px', 
          height: '50px', 
          borderRadius: '50%',
          background: alpha(colors.gold.main, 0.03),
          filter: 'blur(20px)',
          zIndex: 0
        }} 
      />
      <Box 
        sx={{ 
          position: 'absolute', 
          bottom: '30%', 
          left: '5%', 
          width: '80px', 
          height: '80px', 
          borderRadius: '50%',
          background: alpha(colors.gold.main, 0.03),
          filter: 'blur(30px)',
          zIndex: 0
        }} 
      />
      <Box 
        sx={{ 
          position: 'absolute', 
          bottom: '10%', 
          right: '20%', 
          width: '30px', 
          height: '30px', 
          borderRadius: '50%',
          background: alpha(colors.gold.main, 0.03),
          filter: 'blur(15px)',
          zIndex: 0
        }} 
      />
    </Box>
  );
  
  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar position="fixed" open={!isMobile && mobileOpen}>
        <Toolbar sx={{ position: 'relative', overflow: 'hidden' }}>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ 
              mr: 2, 
              display: { md: 'none' },
              color: colors.gold.main,
              '&:hover': {
                backgroundColor: alpha(colors.gold.main, 0.1)
              }
            }}
          >
            <MenuIcon />
          </IconButton>
          
          <Typography 
            variant="h6" 
            noWrap 
            component="div" 
            sx={{ 
              flexGrow: 1,
              fontWeight: 600,
              fontFamily: '"Orbitron", sans-serif',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              color: colors.gold.main,
              textShadow: `0 0 10px ${alpha(colors.gold.main, 0.3)}`,
              display: { xs: 'none', sm: 'block' }
            }}
          >
            {menuItems.find(item => 
              item.path === location.pathname || 
              (location.pathname === '/' && item.path === '/dashboard')
            )?.text || 'Dashboard'}
          </Typography>
          
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Tooltip title="Pesquisar">
              <IconButton 
                sx={{ 
                  mr: 1,
                  color: alpha(colors.text.primary, 0.7),
                  '&:hover': {
                    backgroundColor: alpha(colors.gold.main, 0.1),
                    color: colors.gold.main
                  },
                  transition: 'all 0.3s ease'
                }}
              >
                <Search />
              </IconButton>
            </Tooltip>
            
            <Tooltip title="Notificações">
              <IconButton
                onClick={handleNotificationsOpen}
                sx={{ 
                  mr: 1,
                  color: alpha(colors.text.primary, 0.7),
                  '&:hover': {
                    backgroundColor: alpha(colors.gold.main, 0.1),
                    color: colors.gold.main
                  },
                  transition: 'all 0.3s ease'
                }}
              >
                <Badge 
                  badgeContent={3} 
                  color="error"
                  sx={{
                    '& .MuiBadge-badge': {
                      boxShadow: '0 0 10px rgba(255, 0, 170, 0.5)'
                    }
                  }}
                >
                  <NotificationsIcon />
                </Badge>
              </IconButton>
            </Tooltip>
            
            <Menu
              anchorEl={notificationAnchorEl}
              open={Boolean(notificationAnchorEl)}
              onClose={handleNotificationsClose}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
              PaperProps={{
                sx: {
                  mt: 1,
                  width: 320,
                  maxHeight: 400,
                  borderRadius: 2,
                  background: alpha(colors.black.light, 0.95),
                  backdropFilter: 'blur(10px)',
                  border: `1px solid ${alpha(colors.gold.main, 0.1)}`,
                  boxShadow: '0 8px 30px rgba(0, 0, 0, 0.7)'
                }
              }}
            >
              <MenuItem onClick={handleNotificationsClose}>
                <Box sx={{ width: '100%' }}>
                  <Typography 
                    variant="subtitle2" 
                    fontWeight={600}
                    sx={{ 
                      fontFamily: '"Rajdhani", sans-serif',
                      letterSpacing: '0.03em',
                      color: colors.gold.main
                    }}
                  >
                    Novo sinal de compra: PETR4
                  </Typography>
                  <Typography 
                    variant="body2" 
                    color="text.secondary"
                    sx={{ 
                      fontFamily: '"Space Mono", monospace',
                      fontSize: '0.7rem'
                    }}
                  >
                    Há 5 minutos
                  </Typography>
                </Box>
              </MenuItem>
              <Divider sx={{ borderColor: alpha(colors.gold.main, 0.1) }} />
              <MenuItem onClick={handleNotificationsClose}>
                <Box sx={{ width: '100%' }}>
                  <Typography 
                    variant="subtitle2" 
                    fontWeight={600}
                    sx={{ 
                      fontFamily: '"Rajdhani", sans-serif',
                      letterSpacing: '0.03em',
                      color: colors.error.main
                    }}
                  >
                    Alerta de venda: AAPL
                  </Typography>
                  <Typography 
                    variant="body2" 
                    color="text.secondary"
                    sx={{ 
                      fontFamily: '"Space Mono", monospace',
                      fontSize: '0.7rem'
                    }}
                  >
                    Há 15 minutos
                  </Typography>
                </Box>
              </MenuItem>
              <Divider sx={{ borderColor: alpha(colors.gold.main, 0.1) }} />
              <MenuItem onClick={handleNotificationsClose}>
                <Box sx={{ width: '100%' }}>
                  <Typography 
                    variant="subtitle2" 
                    fontWeight={600}
                    sx={{ 
                      fontFamily: '"Rajdhani", sans-serif',
                      letterSpacing: '0.03em',
                      color: colors.info.main
                    }}
                  >
                    Atualização do sistema v2.0.1
                  </Typography>
                  <Typography 
                    variant="body2" 
                    color="text.secondary"
                    sx={{ 
                      fontFamily: '"Space Mono", monospace',
                      fontSize: '0.7rem'
                    }}
                  >
                    Há 1 hora
                  </Typography>
                </Box>
              </MenuItem>
            </Menu>
            
            <Tooltip title="Perfil">
              <IconButton
                onClick={handleProfileMenuOpen}
                sx={{ 
                  color: alpha(colors.text.primary, 0.7),
                  '&:hover': {
                    backgroundColor: alpha(colors.gold.main, 0.1),
                    color: colors.gold.main
                  },
                  transition: 'all 0.3s ease'
                }}
              >
                <Badge
                  variant="dot"
                  color="success"
                  overlap="circular"
                  anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'right',
                  }}
                  sx={{
                    '& .MuiBadge-badge': {
                      boxShadow: '0 0 10px rgba(0, 230, 118, 0.7)'
                    }
                  }}
                >
                  <Avatar 
                    sx={{ 
                      width: 32, 
                      height: 32,
                      bgcolor: colors.gold.main,
                      color: colors.black.main,
                      fontWeight: 'bold',
                      border: `2px solid ${alpha(colors.gold.main, 0.3)}`,
                      boxShadow: `0 0 10px ${alpha(colors.gold.main, 0.3)}`
                    }}
                  >
                    R
                  </Avatar>
                </Badge>
              </IconButton>
            </Tooltip>
            
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleProfileMenuClose}
              transformOrigin={{ horizontal: 'right', vertical: 'top' }}
              anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
              PaperProps={{
                sx: {
                  mt: 1,
                  width: 200,
                  borderRadius: 2,
                  background: alpha(colors.black.light, 0.95),
                  backdropFilter: 'blur(10px)',
                  border: `1px solid ${alpha(colors.gold.main, 0.1)}`,
                  boxShadow: '0 8px 30px rgba(0, 0, 0, 0.7)'
                }
              }}
            >
              <MenuItem onClick={handleProfileMenuClose}>
                <ListItemIcon>
                  <AccountCircle sx={{ color: colors.gold.main }} />
                </ListItemIcon>
                <ListItemText 
                  primary="Perfil" 
                  primaryTypographyProps={{
                    fontFamily: '"Rajdhani", sans-serif',
                    letterSpacing: '0.03em',
                  }}
                />
              </MenuItem>
              <MenuItem onClick={handleProfileMenuClose}>
                <ListItemIcon>
                  <Settings sx={{ color: colors.gold.main }} />
                </ListItemIcon>
                <ListItemText 
                  primary="Configurações" 
                  primaryTypographyProps={{
                    fontFamily: '"Rajdhani", sans-serif',
                    letterSpacing: '0.03em',
                  }}
                />
              </MenuItem>
              <Divider sx={{ borderColor: alpha(colors.gold.main, 0.1) }} />
              <MenuItem onClick={handleLogout}>
                <ListItemIcon>
                  <LogoutIcon sx={{ color: colors.error.main }} />
                </ListItemIcon>
                <ListItemText 
                  primary="Sair" 
                  primaryTypographyProps={{
                    fontFamily: '"Rajdhani", sans-serif',
                    letterSpacing: '0.03em',
                  }}
                />
              </MenuItem>
            </Menu>
          </Box>
          
          {/* Elementos decorativos */}
          <Box 
            sx={{ 
              position: 'absolute', 
              top: 0, 
              left: 0, 
              width: '100%', 
              height: '1px', 
              background: `linear-gradient(to right, transparent, ${alpha(colors.gold.main, 0.2)}, transparent)`,
              zIndex: 0
            }} 
          />
        </Toolbar>
      </AppBar>
      
      <Box
        component="nav"
        sx={{ width: { md: drawerWidth }, flexShrink: { md: 0 } }}
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true, // Better open performance on mobile.
          }}
          sx={{
            display: { xs: 'block', md: 'none' },
            '& .MuiDrawer-paper': { 
              width: drawerWidth, 
              boxSizing: 'border-box',
              borderRight: 'none',
              boxShadow: '5px 0 20px rgba(0, 0, 0, 0.5)'
            },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: 'none', md: 'block' },
            '& .MuiDrawer-paper': { 
              width: drawerWidth, 
              boxSizing: 'border-box',
              borderRight: 'none',
              boxShadow: '5px 0 20px rgba(0, 0, 0, 0.5)'
            },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      
      <Box
        component="main"
        sx={{ 
          flexGrow: 1, 
          p: 3, 
          width: { md: `calc(100% - ${drawerWidth}px)` },
          mt: '64px',
          position: 'relative',
          minHeight: 'calc(100vh - 64px)',
          background: `radial-gradient(circle at 50% 50%, ${alpha(colors.background.light, 0.4)} 0%, ${alpha(colors.background.default, 0.95)} 100%)`,
        }}
      >
        <Outlet />
        
        {/* Elementos decorativos */}
        <Box 
          sx={{ 
            position: 'absolute', 
            top: '5%', 
            right: '10%', 
            width: '200px', 
            height: '200px', 
            borderRadius: '50%',
            background: alpha(colors.gold.main, 0.02),
            filter: 'blur(70px)',
            zIndex: 0,
            pointerEvents: 'none'
          }} 
        />
        <Box 
          sx={{ 
            position: 'absolute', 
            bottom: '10%', 
            left: '5%', 
            width: '300px', 
            height: '300px', 
            borderRadius: '50%',
            background: alpha(colors.gold.main, 0.01),
            filter: 'blur(100px)',
            zIndex: 0,
            pointerEvents: 'none'
          }} 
        />
      </Box>
    </Box>
  );
};

export default Layout;
