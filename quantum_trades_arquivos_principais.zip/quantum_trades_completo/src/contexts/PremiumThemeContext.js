import React, { createContext, useState, useContext, useEffect } from 'react';
import { ThemeProvider } from '@mui/material/styles';
import theme from '../theme';

// Contexto para gerenciar o tema premium
const PremiumThemeContext = createContext();

export const PremiumThemeProvider = ({ children }) => {
  const [animations, setAnimations] = useState(true);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  
  // Verificar preferências do sistema para redução de movimento
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mediaQuery.matches) {
      setReducedMotion(true);
      setAnimations(false);
    }
    
    const handleChange = (e) => {
      setReducedMotion(e.matches);
      setAnimations(!e.matches);
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);
  
  // Aplicar classes CSS globais com base nas preferências
  useEffect(() => {
    if (reducedMotion || !animations) {
      document.body.classList.add('reduced-motion');
    } else {
      document.body.classList.remove('reduced-motion');
    }
    
    if (highContrast) {
      document.body.classList.add('high-contrast');
    } else {
      document.body.classList.remove('high-contrast');
    }
  }, [animations, reducedMotion, highContrast]);
  
  const toggleAnimations = () => {
    setAnimations(prev => !prev);
  };
  
  const toggleHighContrast = () => {
    setHighContrast(prev => !prev);
  };
  
  return (
    <PremiumThemeContext.Provider 
      value={{
        animations,
        reducedMotion,
        highContrast,
        toggleAnimations,
        toggleHighContrast
      }}
    >
      <ThemeProvider theme={theme}>
        {children}
      </ThemeProvider>
    </PremiumThemeContext.Provider>
  );
};

export const usePremiumTheme = () => useContext(PremiumThemeContext);

export default PremiumThemeContext;
