/**
 * AuthContext.js
 * Contexto de autenticação para gerenciar estado global de autenticação
 */

import React, { createContext, useState, useEffect, useContext } from 'react';
import AuthService from '../services/AuthService';

// Cria o contexto de autenticação
const AuthContext = createContext(null);

// Provedor do contexto de autenticação
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Verifica autenticação ao iniciar
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Verifica se o usuário está autenticado
        if (AuthService.isUserAuthenticated()) {
          const currentUser = AuthService.getCurrentUser();
          setUser(currentUser);
          setIsAuthenticated(true);
        }
      } catch (err) {
        console.error('Erro ao verificar autenticação:', err);
        setError('Falha ao verificar autenticação');
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  // Função de login
  const login = async (username, password) => {
    setLoading(true);
    setError(null);

    try {
      const result = await AuthService.login(username, password);
      
      if (result.success) {
        setUser(result.user);
        setIsAuthenticated(true);
        return { success: true };
      } else {
        setError(result.message);
        return { success: false, message: result.message };
      }
    } catch (err) {
      console.error('Erro durante login:', err);
      setError('Falha ao realizar login. Tente novamente.');
      return { success: false, message: 'Falha ao realizar login. Tente novamente.' };
    } finally {
      setLoading(false);
    }
  };

  // Função de logout
  const logout = async () => {
    setLoading(true);

    try {
      await AuthService.logout();
      setUser(null);
      setIsAuthenticated(false);
    } catch (err) {
      console.error('Erro durante logout:', err);
      setError('Falha ao realizar logout');
    } finally {
      setLoading(false);
    }
  };

  // Função para atualizar dados do usuário
  const updateUserData = async (userData) => {
    setLoading(true);
    setError(null);

    try {
      const result = await AuthService.updateUserData(userData);
      
      if (result.success) {
        setUser(result.user);
        return { success: true };
      } else {
        setError(result.message);
        return { success: false, message: result.message };
      }
    } catch (err) {
      console.error('Erro ao atualizar dados do usuário:', err);
      setError('Falha ao atualizar dados do usuário');
      return { success: false, message: 'Falha ao atualizar dados do usuário' };
    } finally {
      setLoading(false);
    }
  };

  // Função para recuperar senha
  const recoverPassword = async (email) => {
    setLoading(true);
    setError(null);

    try {
      const result = await AuthService.recoverPassword(email);
      return result;
    } catch (err) {
      console.error('Erro ao recuperar senha:', err);
      setError('Falha ao processar recuperação de senha');
      return { success: false, message: 'Falha ao processar recuperação de senha' };
    } finally {
      setLoading(false);
    }
  };

  // Função para registrar novo usuário
  const register = async (userData) => {
    setLoading(true);
    setError(null);

    try {
      const result = await AuthService.register(userData);
      return result;
    } catch (err) {
      console.error('Erro ao registrar usuário:', err);
      setError('Falha ao registrar usuário');
      return { success: false, message: 'Falha ao registrar usuário' };
    } finally {
      setLoading(false);
    }
  };

  // Verifica se o usuário tem permissão para acessar determinado recurso
  const hasPermission = (requiredLevel) => {
    return AuthService.hasPermission(requiredLevel);
  };

  // Valor do contexto
  const value = {
    user,
    isAuthenticated,
    loading,
    error,
    login,
    logout,
    updateUserData,
    recoverPassword,
    register,
    hasPermission
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Hook personalizado para usar o contexto de autenticação
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
};

export default AuthContext;
