/**
 * BackgroundService.js
 * Serviço para execução de tarefas em background e envio automático de ordens
 */

class BackgroundService {
  constructor() {
    this.isRunning = false;
    this.tasks = [];
    this.interval = null;
    this.orderQueue = [];
    this.processedOrders = [];
    this.listeners = {};
  }

  /**
   * Inicia o serviço de background
   * @param {number} checkInterval - Intervalo em milissegundos para verificação de tarefas
   * @returns {boolean} Status do serviço
   */
  start(checkInterval = 5000) {
    if (this.isRunning) {
      console.log('Serviço de background já está em execução.');
      return true;
    }

    console.log(`Iniciando serviço de background com intervalo de ${checkInterval}ms...`);
    
    this.isRunning = true;
    this.interval = setInterval(() => this.processTasks(), checkInterval);
    
    console.log('Serviço de background iniciado com sucesso!');
    this.emit('serviceStarted', { timestamp: new Date().toISOString() });
    
    return true;
  }

  /**
   * Para o serviço de background
   * @returns {boolean} Status da operação
   */
  stop() {
    if (!this.isRunning) {
      console.log('Serviço de background não está em execução.');
      return true;
    }

    console.log('Parando serviço de background...');
    
    clearInterval(this.interval);
    this.interval = null;
    this.isRunning = false;
    
    console.log('Serviço de background parado com sucesso!');
    this.emit('serviceStopped', { timestamp: new Date().toISOString() });
    
    return true;
  }

  /**
   * Adiciona uma tarefa ao serviço de background
   * @param {Object} task - Tarefa a ser executada
   * @returns {string} ID da tarefa
   */
  addTask(task) {
    if (!task.id) {
      task.id = `task_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    }
    
    task.status = 'pending';
    task.createdAt = new Date().toISOString();
    
    this.tasks.push(task);
    console.log(`Tarefa ${task.id} adicionada ao serviço de background.`);
    
    this.emit('taskAdded', { taskId: task.id, task });
    
    return task.id;
  }

  /**
   * Remove uma tarefa do serviço de background
   * @param {string} taskId - ID da tarefa a ser removida
   * @returns {boolean} Status da operação
   */
  removeTask(taskId) {
    const initialLength = this.tasks.length;
    this.tasks = this.tasks.filter(task => task.id !== taskId);
    
    const removed = this.tasks.length < initialLength;
    
    if (removed) {
      console.log(`Tarefa ${taskId} removida do serviço de background.`);
      this.emit('taskRemoved', { taskId });
    } else {
      console.log(`Tarefa ${taskId} não encontrada.`);
    }
    
    return removed;
  }

  /**
   * Processa as tarefas pendentes
   * @private
   */
  processTasks() {
    if (!this.isRunning || this.tasks.length === 0) {
      return;
    }
    
    console.log(`Processando ${this.tasks.length} tarefas...`);
    
    this.tasks.forEach(task => {
      if (task.status === 'pending') {
        this.executeTask(task);
      }
    });
    
    // Processa a fila de ordens
    this.processOrderQueue();
  }

  /**
   * Executa uma tarefa específica
   * @private
   * @param {Object} task - Tarefa a ser executada
   */
  executeTask(task) {
    console.log(`Executando tarefa ${task.id}...`);
    
    task.status = 'processing';
    task.startedAt = new Date().toISOString();
    
    this.emit('taskStarted', { taskId: task.id, task });
    
    // Simulação de execução de tarefa
    setTimeout(() => {
      try {
        // Executa a tarefa com base no tipo
        switch (task.type) {
          case 'analysis':
            this.performAnalysis(task);
            break;
          case 'order':
            this.queueOrder(task);
            break;
          case 'notification':
            this.sendNotification(task);
            break;
          default:
            console.log(`Tipo de tarefa desconhecido: ${task.type}`);
            task.status = 'failed';
            task.error = `Tipo de tarefa desconhecido: ${task.type}`;
        }
        
        if (task.status !== 'failed') {
          task.status = 'completed';
          task.completedAt = new Date().toISOString();
          console.log(`Tarefa ${task.id} concluída com sucesso.`);
          this.emit('taskCompleted', { taskId: task.id, task });
        } else {
          console.log(`Tarefa ${task.id} falhou: ${task.error}`);
          this.emit('taskFailed', { taskId: task.id, task, error: task.error });
        }
      } catch (error) {
        task.status = 'failed';
        task.error = error.message;
        console.error(`Erro ao executar tarefa ${task.id}:`, error);
        this.emit('taskFailed', { taskId: task.id, task, error: error.message });
      }
    }, 1000);
  }

  /**
   * Realiza análise de padrões
   * @private
   * @param {Object} task - Tarefa de análise
   */
  performAnalysis(task) {
    console.log(`Realizando análise para ${task.data.symbol}...`);
    
    // Simulação de análise
    const result = {
      symbol: task.data.symbol,
      pattern: task.data.pattern,
      historicalPotential: Math.random() * 10,
      recentPotential: Math.random() * 8,
      adjustedGain: Math.random() * 7,
      confidence: Math.floor(Math.random() * 100),
      recommendation: 'Compra recomendada com base na análise de padrões.',
      timestamp: new Date().toISOString()
    };
    
    task.result = result;
    
    // Se a análise indicar compra e a confiança for alta, cria ordem automática
    if (result.adjustedGain > 5 && result.confidence > 70) {
      this.queueOrder({
        type: 'order',
        data: {
          symbol: result.symbol,
          operation: 'buy',
          quantity: 100,
          price: 0, // Preço de mercado
          source: 'auto',
          analysisId: task.id
        }
      });
    }
  }

  /**
   * Adiciona uma ordem à fila de processamento
   * @private
   * @param {Object} task - Tarefa de ordem
   */
  queueOrder(task) {
    console.log(`Adicionando ordem à fila: ${task.data.symbol} - ${task.data.operation}`);
    
    const order = {
      id: `order_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      symbol: task.data.symbol,
      operation: task.data.operation,
      quantity: task.data.quantity,
      price: task.data.price,
      status: 'queued',
      source: task.data.source || 'manual',
      createdAt: new Date().toISOString()
    };
    
    this.orderQueue.push(order);
    task.result = { orderId: order.id };
    
    this.emit('orderQueued', { order });
  }

  /**
   * Processa a fila de ordens
   * @private
   */
  processOrderQueue() {
    if (this.orderQueue.length === 0) {
      return;
    }
    
    console.log(`Processando ${this.orderQueue.length} ordens na fila...`);
    
    // Processa cada ordem na fila
    this.orderQueue.forEach(order => {
      console.log(`Enviando ordem ${order.id}: ${order.symbol} - ${order.operation}`);
      
      order.status = 'processing';
      order.processedAt = new Date().toISOString();
      
      this.emit('orderProcessing', { order });
      
      // Simulação de envio de ordem
      setTimeout(() => {
        // Simula 90% de sucesso nas ordens
        const success = Math.random() < 0.9;
        
        if (success) {
          order.status = 'completed';
          order.completedAt = new Date().toISOString();
          order.executedPrice = order.price || (Math.random() * 10 + 20).toFixed(2); // Preço simulado
          
          this.processedOrders.push(order);
          console.log(`Ordem ${order.id} executada com sucesso ao preço ${order.executedPrice}.`);
          
          this.emit('orderCompleted', { order });
          
          // Envia notificação
          this.sendNotification({
            type: 'notification',
            data: {
              type: 'order_completed',
              title: 'Ordem Executada',
              message: `Sua ordem de ${order.operation === 'buy' ? 'compra' : 'venda'} de ${order.quantity} ${order.symbol} foi executada com sucesso ao preço ${order.executedPrice}.`,
              orderId: order.id
            }
          });
        } else {
          order.status = 'failed';
          order.error = 'Falha na execução da ordem.';
          
          console.log(`Ordem ${order.id} falhou: ${order.error}`);
          this.emit('orderFailed', { order, error: order.error });
          
          // Envia notificação de falha
          this.sendNotification({
            type: 'notification',
            data: {
              type: 'order_failed',
              title: 'Falha na Ordem',
              message: `Sua ordem de ${order.operation === 'buy' ? 'compra' : 'venda'} de ${order.quantity} ${order.symbol} falhou: ${order.error}`,
              orderId: order.id
            }
          });
        }
      }, 2000);
    });
    
    // Limpa a fila de ordens
    this.orderQueue = [];
  }

  /**
   * Envia uma notificação
   * @private
   * @param {Object} task - Tarefa de notificação
   */
  sendNotification(task) {
    console.log(`Enviando notificação: ${task.data.title}`);
    
    const notification = {
      id: `notification_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      type: task.data.type,
      title: task.data.title,
      message: task.data.message,
      timestamp: new Date().toISOString(),
      read: false
    };
    
    // Simulação de envio de notificação
    this.emit('notification', { notification });
    
    if (task.result) {
      task.result.notificationId = notification.id;
    } else {
      task.result = { notificationId: notification.id };
    }
  }

  /**
   * Obtém o histórico de ordens processadas
   * @returns {Array} Histórico de ordens
   */
  getOrderHistory() {
    return [...this.processedOrders];
  }

  /**
   * Obtém o status atual do serviço
   * @returns {Object} Status do serviço
   */
  getStatus() {
    return {
      isRunning: this.isRunning,
      pendingTasks: this.tasks.filter(task => task.status === 'pending').length,
      processingTasks: this.tasks.filter(task => task.status === 'processing').length,
      completedTasks: this.tasks.filter(task => task.status === 'completed').length,
      failedTasks: this.tasks.filter(task => task.status === 'failed').length,
      queuedOrders: this.orderQueue.length,
      processedOrders: this.processedOrders.length,
      uptime: this.isRunning ? (Date.now() - new Date(this.tasks[0]?.createdAt || Date.now()).getTime()) : 0
    };
  }

  /**
   * Registra um listener para eventos
   * @param {string} event - Nome do evento
   * @param {Function} callback - Função de callback
   */
  on(event, callback) {
    if (!this.listeners[event]) {
      this.listeners[event] = [];
    }
    
    this.listeners[event].push(callback);
  }

  /**
   * Remove um listener de eventos
   * @param {string} event - Nome do evento
   * @param {Function} callback - Função de callback
   */
  off(event, callback) {
    if (!this.listeners[event]) {
      return;
    }
    
    this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
  }

  /**
   * Emite um evento
   * @private
   * @param {string} event - Nome do evento
   * @param {Object} data - Dados do evento
   */
  emit(event, data) {
    if (!this.listeners[event]) {
      return;
    }
    
    this.listeners[event].forEach(callback => {
      try {
        callback(data);
      } catch (error) {
        console.error(`Erro ao executar listener para evento ${event}:`, error);
      }
    });
  }
}

// Exporta uma instância única do serviço
const backgroundService = new BackgroundService();
export default backgroundService;
