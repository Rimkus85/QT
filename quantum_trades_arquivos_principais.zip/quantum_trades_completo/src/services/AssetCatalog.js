/**
 * AssetCatalog.js
 * Serviço para gerenciamento do catálogo expandido de ativos
 */

class AssetCatalog {
  // Categorias de ativos
  static CATEGORIES = {
    B3: 'b3',
    SP: 'sp500',
    CRYPTO: 'crypto'
  };

  /**
   * Obtém a lista completa de ativos disponíveis
   * @param {string} category - Categoria opcional para filtrar (b3, sp500, crypto)
   * @returns {Promise<Array>} Lista de ativos
   */
  static async getAssets(category = null) {
    try {
      // Simula chamada à API para obter ativos
      const assets = await this.fetchAssets();
      
      // Filtra por categoria se especificada
      if (category) {
        return assets.filter(asset => asset.category === category);
      }
      
      return assets;
    } catch (error) {
      console.error('Erro ao obter lista de ativos:', error);
      throw new Error('Falha ao carregar o catálogo de ativos');
    }
  }

  /**
   * Busca ativos por termo de pesquisa
   * @param {string} searchTerm - Termo para busca
   * @returns {Promise<Array>} Lista de ativos filtrados
   */
  static async searchAssets(searchTerm) {
    try {
      const assets = await this.fetchAssets();
      
      if (!searchTerm) return assets;
      
      const term = searchTerm.toLowerCase();
      
      return assets.filter(asset => 
        asset.symbol.toLowerCase().includes(term) || 
        asset.name.toLowerCase().includes(term)
      );
    } catch (error) {
      console.error('Erro ao buscar ativos:', error);
      throw new Error('Falha ao buscar ativos');
    }
  }

  /**
   * Obtém detalhes de um ativo específico
   * @param {string} symbol - Símbolo do ativo
   * @returns {Promise<Object>} Detalhes do ativo
   */
  static async getAssetDetails(symbol) {
    try {
      const assets = await this.fetchAssets();
      const asset = assets.find(a => a.symbol === symbol);
      
      if (!asset) {
        throw new Error(`Ativo ${symbol} não encontrado`);
      }
      
      // Simula obtenção de detalhes adicionais
      return {
        ...asset,
        lastUpdate: new Date().toISOString(),
        marketCap: this.generateRandomMarketCap(asset.category),
        volume: this.generateRandomVolume(asset.category),
        priceHistory: this.generateMockPriceHistory()
      };
    } catch (error) {
      console.error(`Erro ao obter detalhes do ativo ${symbol}:`, error);
      throw new Error(`Falha ao carregar detalhes do ativo ${symbol}`);
    }
  }

  /**
   * Simula chamada à API para obter lista completa de ativos
   * @private
   * @returns {Promise<Array>} Lista de ativos
   */
  static async fetchAssets() {
    // Simula delay de rede
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Combina ativos de todas as categorias
    return [
      ...this.getB3Assets(),
      ...this.getSP500Assets(),
      ...this.getCryptoAssets()
    ];
  }

  /**
   * Gera lista de ativos da B3
   * @private
   * @returns {Array} Lista de ativos da B3
   */
  static getB3Assets() {
    return [
      { symbol: 'PETR4', name: 'Petrobras PN', category: this.CATEGORIES.B3, sector: 'Petróleo e Gás' },
      { symbol: 'VALE3', name: 'Vale ON', category: this.CATEGORIES.B3, sector: 'Mineração' },
      { symbol: 'ITUB4', name: 'Itaú Unibanco PN', category: this.CATEGORIES.B3, sector: 'Financeiro' },
      { symbol: 'BBDC4', name: 'Bradesco PN', category: this.CATEGORIES.B3, sector: 'Financeiro' },
      { symbol: 'ABEV3', name: 'Ambev ON', category: this.CATEGORIES.B3, sector: 'Bebidas' },
      { symbol: 'MGLU3', name: 'Magazine Luiza ON', category: this.CATEGORIES.B3, sector: 'Varejo' },
      { symbol: 'WEGE3', name: 'WEG ON', category: this.CATEGORIES.B3, sector: 'Bens Industriais' },
      { symbol: 'RENT3', name: 'Localiza ON', category: this.CATEGORIES.B3, sector: 'Locação de Veículos' },
      { symbol: 'BBAS3', name: 'Banco do Brasil ON', category: this.CATEGORIES.B3, sector: 'Financeiro' },
      { symbol: 'RADL3', name: 'Raia Drogasil ON', category: this.CATEGORIES.B3, sector: 'Saúde' },
      // Adicionar mais ações da B3 conforme necessário
    ];
  }

  /**
   * Gera lista de ativos do S&P 500
   * @private
   * @returns {Array} Lista de ativos do S&P 500
   */
  static getSP500Assets() {
    return [
      { symbol: 'AAPL', name: 'Apple Inc.', category: this.CATEGORIES.SP, sector: 'Tecnologia' },
      { symbol: 'MSFT', name: 'Microsoft Corporation', category: this.CATEGORIES.SP, sector: 'Tecnologia' },
      { symbol: 'AMZN', name: 'Amazon.com Inc.', category: this.CATEGORIES.SP, sector: 'Consumo' },
      { symbol: 'GOOGL', name: 'Alphabet Inc. Class A', category: this.CATEGORIES.SP, sector: 'Tecnologia' },
      { symbol: 'META', name: 'Meta Platforms Inc.', category: this.CATEGORIES.SP, sector: 'Tecnologia' },
      { symbol: 'TSLA', name: 'Tesla Inc.', category: this.CATEGORIES.SP, sector: 'Automotivo' },
      { symbol: 'NVDA', name: 'NVIDIA Corporation', category: this.CATEGORIES.SP, sector: 'Tecnologia' },
      { symbol: 'BRK.B', name: 'Berkshire Hathaway Inc. Class B', category: this.CATEGORIES.SP, sector: 'Financeiro' },
      { symbol: 'JNJ', name: 'Johnson & Johnson', category: this.CATEGORIES.SP, sector: 'Saúde' },
      { symbol: 'JPM', name: 'JPMorgan Chase & Co.', category: this.CATEGORIES.SP, sector: 'Financeiro' },
      // Adicionar mais ações do S&P 500 conforme necessário
    ];
  }

  /**
   * Gera lista de criptomoedas
   * @private
   * @returns {Array} Lista de criptomoedas
   */
  static getCryptoAssets() {
    return [
      { symbol: 'BTC', name: 'Bitcoin', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'ETH', name: 'Ethereum', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'BNB', name: 'Binance Coin', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'SOL', name: 'Solana', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'ADA', name: 'Cardano', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'XRP', name: 'Ripple', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'DOT', name: 'Polkadot', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'DOGE', name: 'Dogecoin', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'AVAX', name: 'Avalanche', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      { symbol: 'MATIC', name: 'Polygon', category: this.CATEGORIES.CRYPTO, sector: 'Cryptocurrency' },
      // Adicionar mais criptomoedas conforme necessário
    ];
  }

  /**
   * Gera valor aleatório para capitalização de mercado
   * @private
   * @param {string} category - Categoria do ativo
   * @returns {number} Valor de capitalização de mercado
   */
  static generateRandomMarketCap(category) {
    switch (category) {
      case this.CATEGORIES.B3:
        return Math.random() * 500 + 10; // 10-510 bilhões
      case this.CATEGORIES.SP:
        return Math.random() * 2000 + 100; // 100-2100 bilhões
      case this.CATEGORIES.CRYPTO:
        return Math.random() * 800 + 1; // 1-801 bilhões
      default:
        return Math.random() * 100 + 1; // 1-101 bilhões
    }
  }

  /**
   * Gera valor aleatório para volume
   * @private
   * @param {string} category - Categoria do ativo
   * @returns {number} Valor de volume
   */
  static generateRandomVolume(category) {
    switch (category) {
      case this.CATEGORIES.B3:
        return Math.round(Math.random() * 100000000 + 1000000); // 1M-101M
      case this.CATEGORIES.SP:
        return Math.round(Math.random() * 500000000 + 5000000); // 5M-505M
      case this.CATEGORIES.CRYPTO:
        return Math.round(Math.random() * 10000000000 + 100000000); // 100M-10.1B
      default:
        return Math.round(Math.random() * 10000000 + 100000); // 100K-10.1M
    }
  }

  /**
   * Gera histórico de preços simulado
   * @private
   * @returns {Array} Histórico de preços
   */
  static generateMockPriceHistory() {
    const history = [];
    let price = Math.random() * 100 + 10; // Preço inicial entre 10 e 110
    
    // Gera dados para os últimos 30 dias
    for (let i = 30; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      
      // Variação diária entre -3% e +3%
      const change = (Math.random() * 6 - 3) / 100;
      price = price * (1 + change);
      
      history.push({
        date: date.toISOString().split('T')[0],
        open: price * (1 - Math.random() * 0.01),
        high: price * (1 + Math.random() * 0.02),
        low: price * (1 - Math.random() * 0.02),
        close: price,
        volume: Math.round(Math.random() * 10000000 + 100000)
      });
    }
    
    return history;
  }
}

export default AssetCatalog;
