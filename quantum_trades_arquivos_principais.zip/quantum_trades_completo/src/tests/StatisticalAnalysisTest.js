/**
 * StatisticalAnalysisTest.js
 * Arquivo para testar o serviço de análise estatística
 */

import StatisticalAnalysis from '../services/StatisticalAnalysis.js';

// Dados de teste para simulação
const mockHistoricalData = [
  // Dados simulados de 10 anos atrás
  {
    date: '2015-05-29',
    open: 15.2,
    high: 15.8,
    low: 15.0,
    close: 15.5,
    volume: 10000000,
    subsequentDays: [
      { date: '2015-05-30', open: 15.5, high: 16.2, low: 15.4, close: 16.0, volume: 12000000 },
      { date: '2015-05-31', open: 16.0, high: 16.5, low: 15.8, close: 16.3, volume: 11000000 },
      // Mais dias subsequentes...
    ]
  },
  // Mais dados históricos...
];

const mockRecentData = [
  // Dados simulados dos últimos 2 anos
  {
    date: '2023-05-29',
    open: 22.3,
    high: 22.9,
    low: 22.1,
    close: 22.7,
    volume: 15000000,
    subsequentDays: [
      { date: '2023-05-30', open: 22.7, high: 23.2, low: 22.5, close: 23.0, volume: 16000000 },
      { date: '2023-05-31', open: 23.0, high: 23.5, low: 22.8, close: 23.2, volume: 14000000 },
      // Mais dias subsequentes...
    ]
  },
  // Mais dados recentes...
];

// Padrão de teste (mudança HiLo + sinal martelo + aumento 2% volume)
const testPattern = {
  hiloChange: true,
  hammerSignal: true,
  volumeIncrease: 2
};

// Função para executar os testes
function runTests() {
  console.log('Iniciando testes do serviço de análise estatística...');
  
  // Teste 1: Cálculo de potencial de lucro
  console.log('\nTeste 1: Cálculo de potencial de lucro');
  const result = StatisticalAnalysis.calculateProfitPotential('PETR4', mockHistoricalData, mockRecentData, testPattern);
  console.log('Resultado:', result);
  
  // Teste 2: Verificação de padrão HiLo
  console.log('\nTeste 2: Verificação de padrão HiLo');
  const hiloChangeResult = StatisticalAnalysis.checkHiLoChange(
    { high: 15.8, low: 15.0 },
    { high: 15.0, low: 14.5 }
  );
  console.log('Resultado da verificação HiLo:', hiloChangeResult);
  
  // Teste 3: Verificação de padrão martelo
  console.log('\nTeste 3: Verificação de padrão martelo');
  const hammerSignalResult = StatisticalAnalysis.checkHammerSignal({
    open: 15.5,
    close: 15.6,
    high: 15.7,
    low: 14.8
  });
  console.log('Resultado da verificação de martelo:', hammerSignalResult);
  
  // Teste 4: Verificação de aumento de volume
  console.log('\nTeste 4: Verificação de aumento de volume');
  const volumeIncreaseResult = StatisticalAnalysis.checkVolumeIncrease(
    { volume: 12000000 },
    { volume: 10000000 },
    2
  );
  console.log('Resultado da verificação de aumento de volume:', volumeIncreaseResult);
  
  // Teste 5: Ajuste de gain
  console.log('\nTeste 5: Ajuste de gain');
  const adjustedGain = StatisticalAnalysis.adjustGainBasedOnComparison(10, 8);
  console.log('Gain ajustado:', adjustedGain);
  
  console.log('\nTestes concluídos!');
}

// Executa os testes
runTests();
