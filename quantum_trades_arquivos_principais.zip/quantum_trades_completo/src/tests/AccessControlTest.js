/**
 * AccessControlTest.js
 * Arquivo para testar as funcionalidades do componente de controle de acesso
 */

import React from 'react';
import { render, screen } from '@testing-library/react';
import { AuthProvider } from '../contexts/AuthContext';
import AccessControl from '../components/AccessControl';
import { ACCESS_LEVELS } from '../utils/UserProfileStructure';

// Mock do contexto de autenticação
jest.mock('../contexts/AuthContext', () => ({
  useAuth: () => ({
    isAuthenticated: true,
    hasPermission: (level) => level <= 2, // Simula usuário com nível Premium (2)
    user: {
      id: 1,
      username: 'Rimkus',
      name: 'Rimkus Trader',
      level: 2
    }
  }),
  AuthProvider: ({ children }) => <div>{children}</div>
}));

/**
 * Testes para o componente AccessControl
 */
describe('AccessControl', () => {
  test('Renderiza conteúdo quando usuário tem permissão', () => {
    render(
      <AccessControl requiredLevel={ACCESS_LEVELS.BASIC}>
        <div data-testid="protected-content">Conteúdo Protegido</div>
      </AccessControl>
    );
    
    expect(screen.getByTestId('protected-content')).toBeInTheDocument();
    expect(screen.getByText('Conteúdo Protegido')).toBeInTheDocument();
  });
  
  test('Renderiza conteúdo quando usuário tem nível igual ao requerido', () => {
    render(
      <AccessControl requiredLevel={ACCESS_LEVELS.PREMIUM}>
        <div data-testid="premium-content">Conteúdo Premium</div>
      </AccessControl>
    );
    
    expect(screen.getByTestId('premium-content')).toBeInTheDocument();
    expect(screen.getByText('Conteúdo Premium')).toBeInTheDocument();
  });
  
  test('Não renderiza conteúdo quando usuário não tem permissão', () => {
    render(
      <AccessControl requiredLevel={ACCESS_LEVELS.ADMIN}>
        <div data-testid="admin-content">Conteúdo Admin</div>
      </AccessControl>
    );
    
    expect(screen.queryByTestId('admin-content')).not.toBeInTheDocument();
    expect(screen.queryByText('Conteúdo Admin')).not.toBeInTheDocument();
  });
  
  test('Renderiza fallback quando usuário não tem permissão', () => {
    render(
      <AccessControl 
        requiredLevel={ACCESS_LEVELS.ADMIN}
        fallback={<div data-testid="fallback-content">Acesso Negado</div>}
      >
        <div data-testid="admin-content">Conteúdo Admin</div>
      </AccessControl>
    );
    
    expect(screen.queryByTestId('admin-content')).not.toBeInTheDocument();
    expect(screen.getByTestId('fallback-content')).toBeInTheDocument();
    expect(screen.getByText('Acesso Negado')).toBeInTheDocument();
  });
  
  test('Não renderiza nada quando hideCompletely é true e usuário não tem permissão', () => {
    render(
      <AccessControl 
        requiredLevel={ACCESS_LEVELS.ADMIN}
        hideCompletely={true}
        fallback={<div data-testid="fallback-content">Acesso Negado</div>}
      >
        <div data-testid="admin-content">Conteúdo Admin</div>
      </AccessControl>
    );
    
    expect(screen.queryByTestId('admin-content')).not.toBeInTheDocument();
    expect(screen.queryByTestId('fallback-content')).not.toBeInTheDocument();
  });
});

export default {};
