/**
 * AuthServiceTest.js
 * Arquivo para testar as funcionalidades do serviço de autenticação aprimorado
 */

import authService from '../services/AuthService';

/**
 * Testa as funcionalidades do serviço de autenticação
 */
const testAuthService = () => {
  console.log('=== INICIANDO TESTES DO SERVIÇO DE AUTENTICAÇÃO ===');
  
  // Teste de login
  console.log('\n1. Teste de login:');
  authService.login('Rimkus', 'password123')
    .then(result => {
      console.log('Login bem-sucedido:', result.success);
      console.log('Usuário:', result.user?.username);
      console.log('Token gerado:', result.token ? 'Sim' : 'Não');
      console.log('Expiração definida:', result.expiration ? 'Sim' : 'Não');
      
      // Teste de verificação de autenticação
      console.log('\n2. Teste de verificação de autenticação:');
      const isAuthenticated = authService.isUserAuthenticated();
      console.log('Usuário está autenticado:', isAuthenticated);
      
      // Teste de obtenção de usuário atual
      console.log('\n3. Teste de obtenção de usuário atual:');
      const currentUser = authService.getCurrentUser();
      console.log('Usuário atual:', currentUser?.username);
      console.log('Nível de acesso:', currentUser?.level);
      
      // Teste de verificação de permissão
      console.log('\n4. Teste de verificação de permissão:');
      console.log('Tem permissão nível 1 (Básico):', authService.hasPermission(1));
      console.log('Tem permissão nível 2 (Premium):', authService.hasPermission(2));
      console.log('Tem permissão nível 3 (Admin):', authService.hasPermission(3));
      
      // Teste de renovação de token
      console.log('\n5. Teste de renovação de token:');
      authService.renewToken()
        .then(renewResult => {
          console.log('Token renovado:', renewResult.success);
          console.log('Novo token gerado:', renewResult.token ? 'Sim' : 'Não');
          
          // Teste de logout
          console.log('\n6. Teste de logout:');
          authService.logout()
            .then(logoutResult => {
              console.log('Logout realizado:', logoutResult.success);
              console.log('Usuário ainda está autenticado:', authService.isUserAuthenticated());
              console.log('Usuário atual após logout:', authService.getCurrentUser());
              
              // Teste de persistência após logout
              console.log('\n7. Teste de persistência após logout:');
              console.log('Token após logout:', authService.getToken());
              console.log('Expiração após logout:', authService.getTokenExpiration());
              
              console.log('\n=== TESTES CONCLUÍDOS ===');
            });
        });
    })
    .catch(error => {
      console.error('Erro durante os testes:', error);
    });
};

export default testAuthService;
