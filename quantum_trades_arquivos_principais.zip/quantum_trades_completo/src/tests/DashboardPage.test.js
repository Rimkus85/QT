/**
 * DashboardPage.test.js
 * Testes automatizados para a página de dashboard do Quantum Trades
 */

import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import theme from '../theme';
import DashboardPage from '../pages/DashboardPage';

// Mock dos componentes necessários
jest.mock('../components/ResponsiveCard', () => ({ 
  children, title, content, ...props 
}) => (
  <div data-testid="responsive-card" title={title}>
    {content}
  </div>
));

jest.mock('../components/ResponsiveGrid', () => ({ 
  children, ...props 
}) => (
  <div data-testid="responsive-grid">
    {children}
  </div>
));

// Mock dos dados do dashboard
jest.mock('../services/StatisticalAnalysis', () => ({
  getPortfolioValue: jest.fn().mockReturnValue(125000),
  getPortfolioChange: jest.fn().mockReturnValue(3.75),
  getTopPerformers: jest.fn().mockReturnValue([
    { symbol: 'PETR4', name: 'Petrobras', change: 5.2 },
    { symbol: 'VALE3', name: 'Vale', change: 4.1 },
    { symbol: 'ITUB4', name: 'Itaú', change: 3.8 }
  ]),
  getWorstPerformers: jest.fn().mockReturnValue([
    { symbol: 'MGLU3', name: 'Magazine Luiza', change: -2.7 },
    { symbol: 'BBDC4', name: 'Bradesco', change: -1.9 },
    { symbol: 'ABEV3', name: 'Ambev', change: -1.2 }
  ]),
  getRecentOperations: jest.fn().mockReturnValue([
    { id: 1, type: 'compra', symbol: 'PETR4', quantity: 100, price: 28.75, date: '2025-06-01' },
    { id: 2, type: 'venda', symbol: 'VALE3', quantity: 50, price: 68.30, date: '2025-05-30' }
  ])
}));

// Componente de teste com Provider e Router
const DashboardPageWithProviders = () => (
  <BrowserRouter>
    <ThemeProvider theme={theme}>
      <DashboardPage />
    </ThemeProvider>
  </BrowserRouter>
);

describe('Testes da Página de Dashboard', () => {
  beforeEach(() => {
    // Limpar mocks antes de cada teste
    jest.clearAllMocks();
  });

  test('Deve renderizar corretamente o título do dashboard', async () => {
    render(<DashboardPageWithProviders />);
    
    // Verificar título principal
    expect(screen.getByText(/dashboard/i)).toBeInTheDocument();
  });

  test('Deve renderizar o card de valor total da carteira', async () => {
    render(<DashboardPageWithProviders />);
    
    // Verificar valor da carteira
    await waitFor(() => {
      expect(screen.getByText(/r\$ 125\.000,00/i)).toBeInTheDocument();
    });
    
    // Verificar variação percentual
    await waitFor(() => {
      expect(screen.getByText(/\+3,75%/i)).toBeInTheDocument();
    });
  });

  test('Deve renderizar os cards de ativos em alta', async () => {
    render(<DashboardPageWithProviders />);
    
    // Verificar título da seção
    await waitFor(() => {
      expect(screen.getByText(/ativos em alta/i)).toBeInTheDocument();
    });
    
    // Verificar componentes de grid e cards
    expect(screen.getAllByTestId('responsive-grid').length).toBeGreaterThan(0);
  });

  test('Deve renderizar os cards de ativos em baixa', async () => {
    render(<DashboardPageWithProviders />);
    
    // Verificar título da seção
    await waitFor(() => {
      expect(screen.getByText(/ativos em baixa/i)).toBeInTheDocument();
    });
  });

  test('Deve renderizar os cards de operações recentes', async () => {
    render(<DashboardPageWithProviders />);
    
    // Verificar título da seção
    await waitFor(() => {
      expect(screen.getByText(/operações recentes/i)).toBeInTheDocument();
    });
  });

  test('Deve verificar responsividade em dispositivos móveis', () => {
    // Simular viewport de dispositivo móvel
    window.matchMedia = jest.fn().mockImplementation(query => ({
      matches: query.includes('max-width: 600px'),
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    }));
    
    render(<DashboardPageWithProviders />);
    
    // Verificar adaptações para mobile
    expect(screen.getByText(/dashboard/i)).toBeInTheDocument();
  });
});
