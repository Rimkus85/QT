/**
 * ComponentesVisuais.test.js
 * Testes automatizados para os componentes visuais do Quantum Trades
 */

import React from 'react';
import { render, screen } from '@testing-library/react';
import { ThemeProvider } from '@mui/material/styles';
import theme from '../theme';
import ResponsiveCard from '../components/ResponsiveCard';
import ResponsiveGrid from '../components/ResponsiveGrid';

// Componente de teste com Provider
const TestWrapper = ({ children }) => (
  <ThemeProvider theme={theme}>
    {children}
  </ThemeProvider>
);

describe('Testes do componente ResponsiveCard', () => {
  test('Deve renderizar corretamente com título e conteúdo', () => {
    render(
      <TestWrapper>
        <ResponsiveCard 
          title="Título do Card" 
          subtitle="Subtítulo do Card"
          content={<div data-testid="card-content">Conteúdo do Card</div>}
        />
      </TestWrapper>
    );
    
    expect(screen.getByText('Título do Card')).toBeInTheDocument();
    expect(screen.getByText('Subtítulo do Card')).toBeInTheDocument();
    expect(screen.getByTestId('card-content')).toBeInTheDocument();
  });

  test('Deve renderizar corretamente sem subtítulo', () => {
    render(
      <TestWrapper>
        <ResponsiveCard 
          title="Apenas Título" 
          content={<div>Conteúdo do Card</div>}
        />
      </TestWrapper>
    );
    
    expect(screen.getByText('Apenas Título')).toBeInTheDocument();
    expect(screen.queryByText('Subtítulo do Card')).not.toBeInTheDocument();
  });

  test('Deve aplicar altura mínima corretamente', () => {
    const { container } = render(
      <TestWrapper>
        <ResponsiveCard 
          title="Card com Altura Mínima" 
          content={<div>Conteúdo</div>}
          minHeight={300}
        />
      </TestWrapper>
    );
    
    const card = container.querySelector('.MuiCard-root');
    expect(card).toHaveStyle('min-height: 300px');
  });

  test('Deve verificar responsividade em dispositivos móveis', () => {
    // Simular viewport de dispositivo móvel
    window.matchMedia = jest.fn().mockImplementation(query => ({
      matches: query.includes('max-width: 600px'),
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    }));
    
    render(
      <TestWrapper>
        <ResponsiveCard 
          title="Card Responsivo" 
          content={<div>Conteúdo Responsivo</div>}
        />
      </TestWrapper>
    );
    
    expect(screen.getByText('Card Responsivo')).toBeInTheDocument();
  });
});

describe('Testes do componente ResponsiveGrid', () => {
  test('Deve renderizar corretamente com filhos', () => {
    render(
      <TestWrapper>
        <ResponsiveGrid>
          <div data-testid="grid-item-1">Item 1</div>
          <div data-testid="grid-item-2">Item 2</div>
          <div data-testid="grid-item-3">Item 3</div>
        </ResponsiveGrid>
      </TestWrapper>
    );
    
    expect(screen.getByTestId('grid-item-1')).toBeInTheDocument();
    expect(screen.getByTestId('grid-item-2')).toBeInTheDocument();
    expect(screen.getByTestId('grid-item-3')).toBeInTheDocument();
  });

  test('Deve aplicar espaçamento corretamente', () => {
    const { container } = render(
      <TestWrapper>
        <ResponsiveGrid spacing={4}>
          <div>Item 1</div>
          <div>Item 2</div>
        </ResponsiveGrid>
      </TestWrapper>
    );
    
    const grid = container.querySelector('.MuiGrid-container');
    expect(grid).toBeInTheDocument();
  });

  test('Deve verificar responsividade em dispositivos móveis', () => {
    // Simular viewport de dispositivo móvel
    window.matchMedia = jest.fn().mockImplementation(query => ({
      matches: query.includes('max-width: 600px'),
      media: query,
      onchange: null,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    }));
    
    render(
      <TestWrapper>
        <ResponsiveGrid mobileSpacing={1}>
          <div>Item Mobile 1</div>
          <div>Item Mobile 2</div>
        </ResponsiveGrid>
      </TestWrapper>
    );
    
    expect(screen.getByText('Item Mobile 1')).toBeInTheDocument();
    expect(screen.getByText('Item Mobile 2')).toBeInTheDocument();
  });
});
