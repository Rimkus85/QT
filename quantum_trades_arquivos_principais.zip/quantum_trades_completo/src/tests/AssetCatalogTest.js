/**
 * AssetCatalogTest.js
 * Arquivo para testar o serviço de catálogo de ativos
 */

import AssetCatalog from '../services/AssetCatalog.js';

// Função para executar os testes
async function runTests() {
  console.log('Iniciando testes do serviço de catálogo de ativos...');
  
  try {
    // Teste 1: Obter todos os ativos
    console.log('\nTeste 1: Obter todos os ativos');
    const allAssets = await AssetCatalog.getAssets();
    console.log(`Total de ativos: ${allAssets.length}`);
    console.log('Amostra de ativos:', allAssets.slice(0, 3));
    
    // Teste 2: Filtrar ativos por categoria (B3)
    console.log('\nTeste 2: Filtrar ativos da B3');
    const b3Assets = await AssetCatalog.getAssets(AssetCatalog.CATEGORIES.B3);
    console.log(`Total de ativos B3: ${b3Assets.length}`);
    console.log('Amostra de ativos B3:', b3Assets.slice(0, 3));
    
    // Teste 3: Filtrar ativos por categoria (S&P 500)
    console.log('\nTeste 3: Filtrar ativos do S&P 500');
    const spAssets = await AssetCatalog.getAssets(AssetCatalog.CATEGORIES.SP);
    console.log(`Total de ativos S&P 500: ${spAssets.length}`);
    console.log('Amostra de ativos S&P 500:', spAssets.slice(0, 3));
    
    // Teste 4: Filtrar ativos por categoria (Criptomoedas)
    console.log('\nTeste 4: Filtrar criptomoedas');
    const cryptoAssets = await AssetCatalog.getAssets(AssetCatalog.CATEGORIES.CRYPTO);
    console.log(`Total de criptomoedas: ${cryptoAssets.length}`);
    console.log('Amostra de criptomoedas:', cryptoAssets.slice(0, 3));
    
    // Teste 5: Buscar ativos por termo
    console.log('\nTeste 5: Buscar ativos por termo');
    const searchResults = await AssetCatalog.searchAssets('pet');
    console.log(`Resultados da busca por 'pet': ${searchResults.length}`);
    console.log('Resultados:', searchResults);
    
    // Teste 6: Obter detalhes de um ativo específico
    console.log('\nTeste 6: Obter detalhes de um ativo específico');
    const assetDetails = await AssetCatalog.getAssetDetails('PETR4');
    console.log('Detalhes do ativo PETR4:', assetDetails);
    console.log('Histórico de preços (primeiros 3 dias):', assetDetails.priceHistory.slice(0, 3));
    
    console.log('\nTestes concluídos com sucesso!');
  } catch (error) {
    console.error('Erro durante os testes:', error);
  }
}

// Executa os testes
runTests();
