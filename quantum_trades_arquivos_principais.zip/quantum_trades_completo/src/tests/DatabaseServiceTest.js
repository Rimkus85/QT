/**
 * DatabaseServiceTest.js
 * Arquivo para testar o serviço de banco de dados
 */

import DatabaseService from '../services/DatabaseService.js';

// Função para executar os testes
async function runTests() {
  console.log('Iniciando testes do serviço de banco de dados...');
  
  try {
    // Teste 1: Inicialização da conexão
    console.log('\nTeste 1: Inicialização da conexão');
    const initResult = await DatabaseService.initialize();
    console.log(`Resultado da inicialização: ${initResult}`);
    
    // Teste 2: Configuração de tabelas
    console.log('\nTeste 2: Configuração de tabelas');
    const setupResult = await DatabaseService.setupTables();
    console.log(`Resultado da configuração de tabelas: ${setupResult}`);
    
    // Teste 3: Execução de consulta
    console.log('\nTeste 3: Execução de consulta');
    const queryResult = await DatabaseService.query('SELECT * FROM users LIMIT 10');
    console.log('Resultado da consulta:');
    console.log(queryResult);
    
    // Teste 4: Inserção de dados
    console.log('\nTeste 4: Inserção de dados');
    const insertResult = await DatabaseService.insert('users', {
      name: 'Usuário de Teste',
      email: 'teste@example.com',
      level: 1,
      created_at: new Date().toISOString()
    });
    console.log('Resultado da inserção:');
    console.log(insertResult);
    
    // Teste 5: Atualização de dados
    console.log('\nTeste 5: Atualização de dados');
    const updateResult = await DatabaseService.update('users', 
      { level: 2 },
      { email: 'teste@example.com' }
    );
    console.log('Resultado da atualização:');
    console.log(updateResult);
    
    // Teste 6: Remoção de dados
    console.log('\nTeste 6: Remoção de dados');
    const deleteResult = await DatabaseService.delete('users', 
      { email: 'teste@example.com' }
    );
    console.log('Resultado da remoção:');
    console.log(deleteResult);
    
    // Teste 7: Backup do banco de dados
    console.log('\nTeste 7: Backup do banco de dados');
    const backupResult = await DatabaseService.backup('./backup_test');
    console.log('Resultado do backup:');
    console.log(backupResult);
    
    // Teste 8: Fechamento da conexão
    console.log('\nTeste 8: Fechamento da conexão');
    const closeResult = await DatabaseService.close();
    console.log(`Resultado do fechamento da conexão: ${closeResult}`);
    
    console.log('\nTestes concluídos com sucesso!');
  } catch (error) {
    console.error('Erro durante os testes:', error);
  }
}

// Executa os testes
runTests();
