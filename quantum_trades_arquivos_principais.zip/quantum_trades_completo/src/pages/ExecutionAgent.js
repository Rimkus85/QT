import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  Card, 
  CardContent, 
  CardHeader,
  Divider,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Tooltip,
  useTheme,
  alpha,
  CircularProgress,
  Slider,
  LinearProgress
} from '@mui/material';
import { 
  Code,
  PlayArrow,
  Stop,
  Save,
  Refresh,
  Settings,
  Info,
  ArrowUpward,
  ArrowDownward,
  History,
  BarChart,
  FilterList,
  Search,
  Delete,
  Edit,
  Psychology,
  Autorenew,
  BubbleChart,
  Timeline,
  TrendingUp,
  TrendingDown,
  Send,
  Sync,
  SettingsRemote,
  CheckCircle,
  Error,
  Warning,
  Add
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { colors } from '../theme';

// Componente de TabPanel para as abas
const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`execution-tabpanel-${index}`}
      aria-labelledby={`execution-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Função para criar propriedades de acessibilidade para as abas
const a11yProps = (index) => {
  return {
    id: `execution-tab-${index}`,
    'aria-controls': `execution-tabpanel-${index}`,
  };
};

// Componente para exibir um card de status de conexão
const ConnectionStatusCard = ({ platform, status, lastSync, icon }) => {
  const getStatusColor = () => {
    switch (status) {
      case 'connected':
        return 'success.main';
      case 'connecting':
        return 'warning.main';
      case 'disconnected':
        return 'error.main';
      default:
        return 'text.secondary';
    }
  };
  
  const getStatusIcon = () => {
    switch (status) {
      case 'connected':
        return <CheckCircle fontSize="small" sx={{ color: 'success.main' }} />;
      case 'connecting':
        return <Sync fontSize="small" sx={{ color: 'warning.main' }} />;
      case 'disconnected':
        return <Error fontSize="small" sx={{ color: 'error.main' }} />;
      default:
        return <Warning fontSize="small" sx={{ color: 'text.secondary' }} />;
    }
  };
  
  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
          <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
            {platform}
          </Typography>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            width: 40,
            height: 40,
            borderRadius: '50%',
            bgcolor: alpha(getStatusColor(), 0.1)
          }}>
            {icon}
          </Box>
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          {getStatusIcon()}
          <Typography 
            variant="body1" 
            sx={{ 
              ml: 1,
              fontWeight: 500,
              color: getStatusColor()
            }}
          >
            {status === 'connected' ? 'Conectado' : status === 'connecting' ? 'Conectando...' : 'Desconectado'}
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary">
          Última sincronização: {lastSync}
        </Typography>
      </CardContent>
    </Card>
  );
};

// Componente para exibir um card de operação
const OperationCard = ({ ticker, market, signal, pattern, volume, stopLoss, stopGain, score, status, timestamp }) => {
  const theme = useTheme();
  
  // Determinar cor do sinal
  const signalColor = signal === 'Compra' ? colors.success.main : colors.error.main;
  
  // Formatar data
  const formattedDate = new Date(timestamp).toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
  
  // Determinar cor do badge de mercado
  let marketBadgeColor;
  switch(market) {
    case 'B3':
      marketBadgeColor = 'success';
      break;
    case 'S&P500':
      marketBadgeColor = 'primary';
      break;
    case 'CRYPTO':
      marketBadgeColor = 'warning';
      break;
    default:
      marketBadgeColor = 'default';
  }
  
  // Determinar cor do status
  const getStatusColor = () => {
    switch (status) {
      case 'executado':
        return 'success.main';
      case 'pendente':
        return 'warning.main';
      case 'cancelado':
        return 'error.main';
      case 'parcial':
        return 'info.main';
      default:
        return 'text.secondary';
    }
  };
  
  return (
    <Card sx={{ height: '100%' }}>
      <CardHeader
        title={
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
              {ticker}
            </Typography>
            <Tooltip title={market}>
              <Box 
                component="span" 
                sx={{ 
                  px: 1.5, 
                  py: 0.5, 
                  borderRadius: '12px', 
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  bgcolor: theme.palette[marketBadgeColor].main,
                  color: theme.palette[marketBadgeColor].contrastText
                }}
              >
                {market}
              </Box>
            </Tooltip>
          </Box>
        }
        subheader={formattedDate}
        action={
          <IconButton aria-label="settings" size="small">
            <Settings fontSize="small" />
          </IconButton>
        }
      />
      <Divider />
      <CardContent>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Sinal:
            </Typography>
            <Typography 
              variant="body1" 
              sx={{ 
                fontWeight: 600, 
                color: signalColor,
                display: 'flex',
                alignItems: 'center'
              }}
            >
              {signal === 'Compra' ? 
                <TrendingUp fontSize="small" sx={{ mr: 0.5 }} /> : 
                <TrendingDown fontSize="small" sx={{ mr: 0.5 }} />
              }
              {signal}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Status:
            </Typography>
            <Typography 
              variant="body1"
              sx={{ 
                fontWeight: 600, 
                color: getStatusColor(),
                textTransform: 'capitalize'
              }}
            >
              {status}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Stop Loss:
            </Typography>
            <Typography 
              variant="body1" 
              className="financial-data"
              color="error.main"
              sx={{ fontWeight: 500 }}
            >
              {stopLoss}%
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Stop Gain:
            </Typography>
            <Typography 
              variant="body1" 
              className="financial-data"
              color="success.main"
              sx={{ fontWeight: 500 }}
            >
              {stopGain}%
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Volume:
            </Typography>
            <Typography variant="body1" className="financial-data">
              {volume}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Score:
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Typography 
                variant="body1" 
                className="financial-data"
                sx={{ 
                  fontWeight: 600,
                  color: 
                    score >= 7 ? colors.success.main : 
                    score >= 5 ? colors.warning.main : 
                    colors.error.main
                }}
              >
                {score}/10
              </Typography>
            </Box>
          </Grid>
        </Grid>
        
        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
          <Button 
            variant="outlined" 
            size="small" 
            color="error"
            sx={{ mr: 1 }}
          >
            Cancelar
          </Button>
          <Button 
            variant="contained" 
            size="small"
            startIcon={<Send />}
          >
            Executar
          </Button>
        </Box>
      </CardContent>
    </Card>
  );
};

// Componente principal do Agente de Execução
const ExecutionAgent = () => {
  const { user } = useAuth();
  const theme = useTheme();
  const [tabValue, setTabValue] = useState(0);
  
  // Estado para controle de execução automática
  const [autoExecution, setAutoExecution] = useState(false);
  
  // Estado para configurações de risco
  const [riskSettings, setRiskSettings] = useState({
    maxRiskPerTrade: 2,
    maxSimultaneousTrades: 5,
    maxDailyRisk: 5,
    stopLossConfirmation: 'auto',
    stopGainAdjustment: 'auto'
  });
  
  // Estado para status de conexão
  const [connectionStatus, setConnectionStatus] = useState({
    profitChart: {
      status: 'connected',
      lastSync: '17/05/2025 19:45'
    },
    binance: {
      status: 'connected',
      lastSync: '17/05/2025 19:48'
    }
  });
  
  // Estado para operações pendentes
  const [pendingOperations, setPendingOperations] = useState([
    {
      id: 1,
      ticker: 'PETR4',
      market: 'B3',
      signal: 'Compra',
      pattern: 'OCO',
      volume: '1.8x',
      stopLoss: -5.2,
      stopGain: 15.0,
      score: 8.5,
      status: 'pendente',
      timestamp: '2025-05-17T15:30:00'
    },
    {
      id: 2,
      ticker: 'AAPL',
      market: 'S&P500',
      signal: 'Venda',
      pattern: 'Topo Duplo',
      volume: '1.5x',
      stopLoss: -4.8,
      stopGain: 12.0,
      score: 7.8,
      status: 'pendente',
      timestamp: '2025-05-17T16:15:00'
    },
    {
      id: 3,
      ticker: 'BTC',
      market: 'CRYPTO',
      signal: 'Compra',
      pattern: 'Engolfo',
      volume: '2.2x',
      stopLoss: -6.5,
      stopGain: 18.0,
      score: 9.2,
      status: 'pendente',
      timestamp: '2025-05-17T16:45:00'
    }
  ]);
  
  // Estado para operações ativas
  const [activeOperations, setActiveOperations] = useState([
    {
      id: 4,
      ticker: 'VALE3',
      market: 'B3',
      signal: 'Compra',
      pattern: 'Mulher Grávida',
      volume: '1.4x',
      stopLoss: -4.5,
      stopGain: 11.0,
      score: 8.1,
      status: 'executado',
      timestamp: '2025-05-17T14:20:00',
      entryPrice: 68.75,
      currentPrice: 71.30,
      currentReturn: 3.71
    },
    {
      id: 5,
      ticker: 'MSFT',
      market: 'S&P500',
      signal: 'Compra',
      pattern: 'OCO',
      volume: '1.6x',
      stopLoss: -5.0,
      stopGain: 12.5,
      score: 7.5,
      status: 'executado',
      timestamp: '2025-05-17T14:05:00',
      entryPrice: 415.20,
      currentPrice: 428.65,
      currentReturn: 3.24
    },
    {
      id: 6,
      ticker: 'ETH',
      market: 'CRYPTO',
      signal: 'Compra',
      pattern: 'Engolfo',
      volume: '2.0x',
      stopLoss: -7.2,
      stopGain: 18.5,
      score: 8.9,
      status: 'executado',
      timestamp: '2025-05-17T13:30:00',
      entryPrice: 3456.78,
      currentPrice: 3678.92,
      currentReturn: 6.43
    }
  ]);
  
  // Manipulador de mudança de aba
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  // Manipulador para alternar execução automática
  const handleAutoExecutionToggle = () => {
    setAutoExecution(!autoExecution);
  };
  
  // Manipulador de mudança de configuração de risco
  const handleRiskSettingChange = (setting, value) => {
    setRiskSettings({
      ...riskSettings,
      [setting]: value
    });
  };
  
  // Manipulador para reconectar plataformas
  const handleReconnect = (platform) => {
    // Simulação de reconexão
    setConnectionStatus({
      ...connectionStatus,
      [platform]: {
        ...connectionStatus[platform],
        status: 'connecting'
      }
    });
    
    // Simulação de conexão bem-sucedida após 2 segundos
    setTimeout(() => {
      setConnectionStatus({
        ...connectionStatus,
        [platform]: {
          status: 'connected',
          lastSync: new Date().toLocaleString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })
        }
      });
    }, 2000);
  };
  
  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ 
        mb: 4, 
        display: 'flex', 
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap'
      }}>
        <Box>
          <Typography variant="h4" component="h1" sx={{ fontWeight: 600, mb: 1 }}>
            Agente de Execução
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Gerenciamento de operações e integração com plataformas
          </Typography>
        </Box>
        
        <Box sx={{ display: 'flex', gap: 2, mt: { xs: 2, md: 0 } }}>
          <FormControlLabel
            control={
              <Switch
                checked={autoExecution}
                onChange={handleAutoExecutionToggle}
                color="primary"
              />
            }
            label="Execução Automática"
          />
          
          <Button 
            variant="contained" 
            startIcon={<Refresh />}
          >
            Atualizar
          </Button>
        </Box>
      </Box>
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <ConnectionStatusCard 
            platform="ProfitChart Pro"
            status={connectionStatus.profitChart.status}
            lastSync={connectionStatus.profitChart.lastSync}
            icon={<SettingsRemote fontSize="small" sx={{ color: colors.primary.main }} />}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <ConnectionStatusCard 
            platform="Binance"
            status={connectionStatus.binance.status}
            lastSync={connectionStatus.binance.lastSync}
            icon={<SettingsRemote fontSize="small" sx={{ color: colors.warning.main }} />}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
                  Capital Disponível
                </Typography>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  width: 40,
                  height: 40,
                  borderRadius: '50%',
                  bgcolor: alpha(colors.success.main, 0.1)
                }}>
                  <BarChart fontSize="small" sx={{ color: colors.success.main }} />
                </Box>
              </Box>
              <Typography 
                variant="h4" 
                component="div" 
                sx={{ 
                  fontWeight: 700, 
                  mb: 1,
                  fontFamily: '"Space Mono", monospace',
                  color: colors.success.main
                }}
                className="financial-data"
              >
                R$ 125.450,00
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <ArrowUpward fontSize="small" sx={{ color: colors.success.main, mr: 0.5 }} />
                <Typography 
                  variant="body2" 
                  sx={{ 
                    fontWeight: 500,
                    color: colors.success.main
                  }}
                >
                  +2,5% hoje
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
                  Operações Ativas
                </Typography>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  width: 40,
                  height: 40,
                  borderRadius: '50%',
                  bgcolor: alpha(colors.info.main, 0.1)
                }}>
                  <BubbleChart fontSize="small" sx={{ color: colors.info.main }} />
                </Box>
              </Box>
              <Typography 
                variant="h4" 
                component="div" 
                sx={{ 
                  fontWeight: 700, 
                  mb: 1,
                  fontFamily: '"Space Mono", monospace',
                }}
              >
                {activeOperations.length}
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Typography 
                  variant="body2" 
                  color="text.secondary"
                  sx={{ fontWeight: 500 }}
                >
                  {pendingOperations.length} operações pendentes
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
      
      <Box sx={{ width: '100%', mb: 4 }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            aria-label="execution agent tabs"
            sx={{
              '& .MuiTabs-indicator': {
                backgroundColor: colors.primary.main,
                height: 3,
                borderRadius: '3px 3px 0 0'
              },
              '& .MuiTab-root': {
                textTransform: 'none',
                fontWeight: 600,
                fontSize: '1rem',
                color: alpha(colors.text.primary, 0.7),
                '&.Mui-selected': {
                  color: colors.primary.main
                }
              }
            }}
          >
            <Tab label="Operações Pendentes" {...a11yProps(0)} />
            <Tab label="Operações Ativas" {...a11yProps(1)} />
            <Tab label="Configurações" {...a11yProps(2)} />
          </Tabs>
        </Box>
        
        <TabPanel value={tabValue} index={0}>
          <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6" component="div">
              Operações Pendentes ({pendingOperations.length})
            </Typography>
            <Box>
              <Button 
                variant="outlined" 
                startIcon={<FilterList />}
                sx={{ mr: 1 }}
              >
                Filtrar
              </Button>
              <Button 
                variant="contained" 
                startIcon={<Add />}
              >
                Nova Operação
              </Button>
            </Box>
          </Box>
          
          <Grid container spacing={3}>
            {pendingOperations.map((operation) => (
              <Grid item xs={12} sm={6} md={4} key={operation.id}>
                <OperationCard {...operation} />
              </Grid>
            ))}
          </Grid>
        </TabPanel>
        
        <TabPanel value={tabValue} index={1}>
          <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6" component="div">
              Operações Ativas ({activeOperations.length})
            </Typography>
            <Box>
              <Button 
                variant="outlined" 
                startIcon={<FilterList />}
                sx={{ mr: 1 }}
              >
                Filtrar
              </Button>
              <Button 
                variant="contained" 
                startIcon={<History />}
              >
                Histórico
              </Button>
            </Box>
          </Box>
          
          <TableContainer component={Paper} sx={{ 
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
            borderRadius: 2,
            overflow: 'hidden',
            border: '1px solid rgba(255, 255, 255, 0.05)'
          }}>
            <Table sx={{ minWidth: 650 }} aria-label="active operations table">
              <TableHead sx={{ 
                bgcolor: alpha(colors.black.light, 0.5),
                '& .MuiTableCell-head': {
                  color: colors.text.primary,
                  fontWeight: 600,
                  fontSize: '0.875rem',
                  borderBottom: `1px solid ${alpha(colors.divider, 0.1)}`
                }
              }}>
                <TableRow>
                  <TableCell>Ticker</TableCell>
                  <TableCell>Mercado</TableCell>
                  <TableCell>Sinal</TableCell>
                  <TableCell>Preço de Entrada</TableCell>
                  <TableCell>Preço Atual</TableCell>
                  <TableCell>Retorno</TableCell>
                  <TableCell>Stop Loss</TableCell>
                  <TableCell>Stop Gain</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell align="right">Ações</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {activeOperations.map((operation) => (
                  <TableRow
                    key={operation.id}
                    sx={{ 
                      '&:last-child td, &:last-child th': { border: 0 },
                      '&:hover': {
                        bgcolor: alpha(colors.primary.main, 0.05)
                      },
                      transition: 'background-color 0.2s ease'
                    }}
                  >
                    <TableCell component="th" scope="row" sx={{ fontWeight: 600 }}>
                      {operation.ticker}
                    </TableCell>
                    <TableCell>
                      <Box 
                        component="span" 
                        sx={{ 
                          px: 1.5, 
                          py: 0.5, 
                          borderRadius: '12px', 
                          fontSize: '0.75rem',
                          fontWeight: 600,
                          bgcolor: operation.market === 'B3' ? 
                            theme.palette.success.main : 
                            operation.market === 'S&P500' ? 
                              theme.palette.primary.main : 
                              theme.palette.warning.main,
                          color: '#fff'
                        }}
                      >
                        {operation.market}
                      </Box>
                    </TableCell>
                    <TableCell sx={{ 
                      color: operation.signal === 'Compra' ? colors.success.main : colors.error.main,
                      fontWeight: 500,
                      display: 'flex',
                      alignItems: 'center'
                    }}>
                      {operation.signal === 'Compra' ? 
                        <TrendingUp fontSize="small" sx={{ mr: 0.5 }} /> : 
                        <TrendingDown fontSize="small" sx={{ mr: 0.5 }} />
                      }
                      {operation.signal}
                    </TableCell>
                    <TableCell className="financial-data">
                      {operation.market === 'B3' ? 'R$ ' : operation.market === 'CRYPTO' ? '$ ' : '$ '}
                      {operation.entryPrice.toFixed(2)}
                    </TableCell>
                    <TableCell className="financial-data">
                      {operation.market === 'B3' ? 'R$ ' : operation.market === 'CRYPTO' ? '$ ' : '$ '}
                      {operation.currentPrice.toFixed(2)}
                    </TableCell>
                    <TableCell sx={{ 
                      color: operation.currentReturn > 0 ? colors.success.main : colors.error.main,
                      fontWeight: 600
                    }}>
                      {operation.currentReturn > 0 ? '+' : ''}{operation.currentReturn.toFixed(2)}%
                    </TableCell>
                    <TableCell sx={{ color: colors.error.main }}>
                      {operation.stopLoss}%
                    </TableCell>
                    <TableCell sx={{ color: colors.success.main }}>
                      {operation.stopGain}%
                    </TableCell>
                    <TableCell>
                      <Box 
                        component="span" 
                        sx={{ 
                          px: 1.5, 
                          py: 0.5, 
                          borderRadius: '12px', 
                          fontSize: '0.75rem',
                          fontWeight: 600,
                          bgcolor: alpha(colors.success.main, 0.1),
                          color: colors.success.main,
                          textTransform: 'capitalize'
                        }}
                      >
                        {operation.status}
                      </Box>
                    </TableCell>
                    <TableCell align="right">
                      <Tooltip title="Editar">
                        <IconButton size="small" sx={{ mr: 1 }}>
                          <Edit fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Encerrar">
                        <IconButton size="small" color="error">
                          <Delete fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </TabPanel>
        
        <TabPanel value={tabValue} index={2}>
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <Paper sx={{ 
                p: 3, 
                borderRadius: 2,
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                border: '1px solid rgba(255, 255, 255, 0.05)'
              }}>
                <Typography variant="h6" component="h2" sx={{ mb: 3, fontWeight: 600 }}>
                  Configurações de Risco
                </Typography>
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" gutterBottom>
                    Risco máximo por operação (%)
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Slider
                      value={riskSettings.maxRiskPerTrade}
                      onChange={(e, newValue) => handleRiskSettingChange('maxRiskPerTrade', newValue)}
                      aria-labelledby="max-risk-per-trade-slider"
                      valueLabelDisplay="auto"
                      step={0.5}
                      min={0.5}
                      max={10}
                      sx={{
                        width: 'calc(100% - 60px)',
                        mr: 2,
                        '& .MuiSlider-thumb': {
                          width: 16,
                          height: 16,
                          '&:hover, &.Mui-focusVisible': {
                            boxShadow: `0 0 0 8px ${alpha(colors.primary.main, 0.16)}`
                          }
                        },
                        '& .MuiSlider-track': {
                          height: 6,
                          borderRadius: 3
                        },
                        '& .MuiSlider-rail': {
                          height: 6,
                          borderRadius: 3,
                          opacity: 0.2
                        }
                      }}
                    />
                    <Typography 
                      variant="body1" 
                      sx={{ 
                        fontWeight: 600,
                        minWidth: 40,
                        textAlign: 'right'
                      }}
                    >
                      {riskSettings.maxRiskPerTrade}%
                    </Typography>
                  </Box>
                </Box>
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" gutterBottom>
                    Operações simultâneas máximas
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Slider
                      value={riskSettings.maxSimultaneousTrades}
                      onChange={(e, newValue) => handleRiskSettingChange('maxSimultaneousTrades', newValue)}
                      aria-labelledby="max-simultaneous-trades-slider"
                      valueLabelDisplay="auto"
                      step={1}
                      min={1}
                      max={20}
                      sx={{
                        width: 'calc(100% - 60px)',
                        mr: 2,
                        '& .MuiSlider-thumb': {
                          width: 16,
                          height: 16,
                          '&:hover, &.Mui-focusVisible': {
                            boxShadow: `0 0 0 8px ${alpha(colors.primary.main, 0.16)}`
                          }
                        },
                        '& .MuiSlider-track': {
                          height: 6,
                          borderRadius: 3
                        },
                        '& .MuiSlider-rail': {
                          height: 6,
                          borderRadius: 3,
                          opacity: 0.2
                        }
                      }}
                    />
                    <Typography 
                      variant="body1" 
                      sx={{ 
                        fontWeight: 600,
                        minWidth: 40,
                        textAlign: 'right'
                      }}
                    >
                      {riskSettings.maxSimultaneousTrades}
                    </Typography>
                  </Box>
                </Box>
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" gutterBottom>
                    Risco diário máximo (%)
                  </Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Slider
                      value={riskSettings.maxDailyRisk}
                      onChange={(e, newValue) => handleRiskSettingChange('maxDailyRisk', newValue)}
                      aria-labelledby="max-daily-risk-slider"
                      valueLabelDisplay="auto"
                      step={0.5}
                      min={1}
                      max={20}
                      sx={{
                        width: 'calc(100% - 60px)',
                        mr: 2,
                        '& .MuiSlider-thumb': {
                          width: 16,
                          height: 16,
                          '&:hover, &.Mui-focusVisible': {
                            boxShadow: `0 0 0 8px ${alpha(colors.primary.main, 0.16)}`
                          }
                        },
                        '& .MuiSlider-track': {
                          height: 6,
                          borderRadius: 3
                        },
                        '& .MuiSlider-rail': {
                          height: 6,
                          borderRadius: 3,
                          opacity: 0.2
                        }
                      }}
                    />
                    <Typography 
                      variant="body1" 
                      sx={{ 
                        fontWeight: 600,
                        minWidth: 40,
                        textAlign: 'right'
                      }}
                    >
                      {riskSettings.maxDailyRisk}%
                    </Typography>
                  </Box>
                </Box>
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" gutterBottom>
                    Confirmação de Stop Loss
                  </Typography>
                  <FormControl fullWidth variant="outlined" size="small">
                    <Select
                      value={riskSettings.stopLossConfirmation}
                      onChange={(e) => handleRiskSettingChange('stopLossConfirmation', e.target.value)}
                      sx={{ 
                        borderRadius: 2,
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: alpha(colors.divider, 0.2)
                        }
                      }}
                    >
                      <MenuItem value="auto">Automático</MenuItem>
                      <MenuItem value="manual">Manual</MenuItem>
                      <MenuItem value="confirm">Confirmar sempre</MenuItem>
                    </Select>
                  </FormControl>
                </Box>
                
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" gutterBottom>
                    Ajuste de Stop Gain
                  </Typography>
                  <FormControl fullWidth variant="outlined" size="small">
                    <Select
                      value={riskSettings.stopGainAdjustment}
                      onChange={(e) => handleRiskSettingChange('stopGainAdjustment', e.target.value)}
                      sx={{ 
                        borderRadius: 2,
                        '& .MuiOutlinedInput-notchedOutline': {
                          borderColor: alpha(colors.divider, 0.2)
                        }
                      }}
                    >
                      <MenuItem value="auto">Automático</MenuItem>
                      <MenuItem value="manual">Manual</MenuItem>
                      <MenuItem value="trailing">Trailing Stop</MenuItem>
                    </Select>
                  </FormControl>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 4 }}>
                  <Button 
                    variant="outlined" 
                    sx={{ mr: 2 }}
                  >
                    Restaurar Padrões
                  </Button>
                  <Button 
                    variant="contained"
                    startIcon={<Save />}
                  >
                    Salvar Configurações
                  </Button>
                </Box>
              </Paper>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Paper sx={{ 
                p: 3, 
                borderRadius: 2,
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                border: '1px solid rgba(255, 255, 255, 0.05)',
                mb: 4
              }}>
                <Typography variant="h6" component="h2" sx={{ mb: 3, fontWeight: 600 }}>
                  Integração com Plataformas
                </Typography>
                
                <Box sx={{ mb: 3 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Typography variant="body1" sx={{ fontWeight: 500 }}>
                      ProfitChart Pro
                    </Typography>
                    <Button 
                      variant="outlined" 
                      size="small"
                      onClick={() => handleReconnect('profitChart')}
                      startIcon={<Autorenew />}
                      color={connectionStatus.profitChart.status === 'connected' ? 'primary' : 'error'}
                    >
                      {connectionStatus.profitChart.status === 'connected' ? 'Reconectar' : 'Conectar'}
                    </Button>
                  </Box>
                  <LinearProgress 
                    variant="determinate" 
                    value={connectionStatus.profitChart.status === 'connected' ? 100 : connectionStatus.profitChart.status === 'connecting' ? 70 : 0} 
                    sx={{ 
                      height: 8, 
                      borderRadius: 4,
                      bgcolor: alpha(colors.divider, 0.1),
                      '& .MuiLinearProgress-bar': {
                        bgcolor: connectionStatus.profitChart.status === 'connected' ? colors.success.main : connectionStatus.profitChart.status === 'connecting' ? colors.warning.main : colors.error.main,
                        borderRadius: 4
                      }
                    }}
                  />
                </Box>
                
                <Box sx={{ mb: 3 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Typography variant="body1" sx={{ fontWeight: 500 }}>
                      Binance
                    </Typography>
                    <Button 
                      variant="outlined" 
                      size="small"
                      onClick={() => handleReconnect('binance')}
                      startIcon={<Autorenew />}
                      color={connectionStatus.binance.status === 'connected' ? 'primary' : 'error'}
                    >
                      {connectionStatus.binance.status === 'connected' ? 'Reconectar' : 'Conectar'}
                    </Button>
                  </Box>
                  <LinearProgress 
                    variant="determinate" 
                    value={connectionStatus.binance.status === 'connected' ? 100 : connectionStatus.binance.status === 'connecting' ? 70 : 0} 
                    sx={{ 
                      height: 8, 
                      borderRadius: 4,
                      bgcolor: alpha(colors.divider, 0.1),
                      '& .MuiLinearProgress-bar': {
                        bgcolor: connectionStatus.binance.status === 'connected' ? colors.success.main : connectionStatus.binance.status === 'connecting' ? colors.warning.main : colors.error.main,
                        borderRadius: 4
                      }
                    }}
                  />
                </Box>
                
                <Box sx={{ mt: 4 }}>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                    Adicione novas plataformas de negociação para expandir suas operações
                  </Typography>
                  <Button 
                    variant="outlined" 
                    fullWidth
                    startIcon={<Add />}
                    sx={{ 
                      borderStyle: 'dashed', 
                      borderWidth: 2,
                      borderRadius: 2,
                      py: 1.5
                    }}
                  >
                    Adicionar Nova Plataforma
                  </Button>
                </Box>
              </Paper>
              
              <Paper sx={{ 
                p: 3, 
                borderRadius: 2,
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                border: '1px solid rgba(255, 255, 255, 0.05)'
              }}>
                <Typography variant="h6" component="h2" sx={{ mb: 3, fontWeight: 600 }}>
                  Configurações Avançadas
                </Typography>
                
                <Box sx={{ mb: 3 }}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={true}
                        color="primary"
                      />
                    }
                    label="Notificações em tempo real"
                  />
                </Box>
                
                <Box sx={{ mb: 3 }}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={true}
                        color="primary"
                      />
                    }
                    label="Confirmação de operações de alto risco"
                  />
                </Box>
                
                <Box sx={{ mb: 3 }}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={false}
                        color="primary"
                      />
                    }
                    label="Modo de operação noturna"
                  />
                </Box>
                
                <Box sx={{ mb: 3 }}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={true}
                        color="primary"
                      />
                    }
                    label="Sincronização com IA Adaptativa"
                  />
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 4 }}>
                  <Button 
                    variant="contained"
                    startIcon={<Save />}
                  >
                    Salvar Configurações
                  </Button>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </TabPanel>
      </Box>
    </Container>
  );
};

export default ExecutionAgent;
