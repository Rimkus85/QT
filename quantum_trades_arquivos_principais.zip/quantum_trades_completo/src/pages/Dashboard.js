import React from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  Card, 
  CardContent, 
  CardHeader,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton,
  Chip,
  useTheme,
  useMediaQuery,
  alpha
} from '@mui/material';
import { 
  TrendingUp, 
  TrendingDown, 
  ShowChart, 
  BarChart, 
  PieChart,
  Timeline,
  Refresh,
  Info,
  ArrowUpward,
  ArrowDownward,
  Search,
  FilterList,
  MoreVert
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { colors } from '../theme';

// Componente para exibir um card de mercado
const MarketCard = ({ title, value, change, changePercent, icon }) => {
  const isPositive = change >= 0;
  
  return (
    <Card sx={{ height: '100%' }}>
      <CardContent>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
          <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
            {title}
          </Typography>
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            width: 40,
            height: 40,
            borderRadius: '50%',
            bgcolor: alpha(isPositive ? colors.success.main : colors.error.main, 0.1)
          }}>
            {icon}
          </Box>
        </Box>
        <Typography variant="h5" component="div" className="financial-data" sx={{ fontWeight: 600, mb: 1 }}>
          {value}
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          {isPositive ? 
            <ArrowUpward fontSize="small" color="success" sx={{ mr: 0.5 }} /> : 
            <ArrowDownward fontSize="small" color="error" sx={{ mr: 0.5 }} />
          }
          <Typography 
            variant="body2" 
            className="financial-data"
            color={isPositive ? 'success.main' : 'error.main'}
            sx={{ fontWeight: 500, mr: 1 }}
          >
            {change > 0 ? '+' : ''}{change}
          </Typography>
          <Typography 
            variant="body2"
            className="financial-data"
            color={isPositive ? 'success.main' : 'error.main'}
            sx={{ fontWeight: 500 }}
          >
            ({changePercent > 0 ? '+' : ''}{changePercent}%)
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
};

// Componente para exibir um card de sinal de trading
const SignalCard = ({ ticker, market, signal, pattern, volume, stopLoss, stopGain, score, timestamp }) => {
  const theme = useTheme();
  
  // Determinar cor do sinal
  const signalColor = signal === 'Compra' ? colors.success.main : colors.error.main;
  
  // Formatar data
  const formattedDate = new Date(timestamp).toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
  
  // Determinar cor do badge de mercado
  let marketBadgeColor;
  switch(market) {
    case 'B3':
      marketBadgeColor = 'success';
      break;
    case 'S&P500':
      marketBadgeColor = 'primary';
      break;
    case 'CRYPTO':
      marketBadgeColor = 'warning';
      break;
    default:
      marketBadgeColor = 'default';
  }
  
  return (
    <Card sx={{ height: '100%' }}>
      <CardHeader
        title={
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
              {ticker}
            </Typography>
            <Chip 
              label={market} 
              size="small" 
              color={marketBadgeColor}
              sx={{ fontWeight: 500 }}
            />
          </Box>
        }
        subheader={formattedDate}
        action={
          <IconButton aria-label="settings" size="small">
            <MoreVert fontSize="small" />
          </IconButton>
        }
      />
      <Divider />
      <CardContent>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Sinal:
            </Typography>
            <Typography 
              variant="body1" 
              sx={{ 
                fontWeight: 600, 
                color: signalColor,
                display: 'flex',
                alignItems: 'center'
              }}
            >
              {signal === 'Compra' ? 
                <TrendingUp fontSize="small" sx={{ mr: 0.5 }} /> : 
                <TrendingDown fontSize="small" sx={{ mr: 0.5 }} />
              }
              {signal}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Padrão:
            </Typography>
            <Typography variant="body1">
              {pattern}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Stop Loss:
            </Typography>
            <Typography 
              variant="body1" 
              className="financial-data"
              color="error.main"
              sx={{ fontWeight: 500 }}
            >
              {stopLoss}%
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Stop Gain:
            </Typography>
            <Typography 
              variant="body1" 
              className="financial-data"
              color="success.main"
              sx={{ fontWeight: 500 }}
            >
              {stopGain}%
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Volume:
            </Typography>
            <Typography variant="body1" className="financial-data">
              {volume}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2" color="text.secondary">
              Score:
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Typography 
                variant="body1" 
                className="financial-data"
                sx={{ 
                  fontWeight: 600,
                  color: 
                    score >= 7 ? colors.success.main : 
                    score >= 5 ? colors.warning.main : 
                    colors.error.main
                }}
              >
                {score}/10
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
};

// Componente principal do Dashboard
const Dashboard = () => {
  const { user } = useAuth();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  // Dados mockados para desenvolvimento
  const marketData = [
    { 
      id: 1, 
      title: 'IBOVESPA', 
      value: '128.457,98', 
      change: 1254.32, 
      changePercent: 0.98, 
      icon: <ShowChart fontSize="small" color="success" />
    },
    { 
      id: 2, 
      title: 'S&P 500', 
      value: '5.123,45', 
      change: -12.67, 
      changePercent: -0.25, 
      icon: <ShowChart fontSize="small" color="error" />
    },
    { 
      id: 3, 
      title: 'BTC/USD', 
      value: '67.892,45', 
      change: 1432.67, 
      changePercent: 2.15, 
      icon: <ShowChart fontSize="small" color="success" />
    },
    { 
      id: 4, 
      title: 'ETH/USD', 
      value: '3.456,78', 
      change: 87.45, 
      changePercent: 2.60, 
      icon: <ShowChart fontSize="small" color="success" />
    }
  ];
  
  const signalData = [
    {
      id: 1,
      ticker: 'PETR4',
      market: 'B3',
      signal: 'Compra',
      pattern: 'OCO',
      volume: '1.5x',
      stopLoss: -5.2,
      stopGain: 12.8,
      score: 8.5,
      timestamp: '2025-05-17T10:30:00'
    },
    {
      id: 2,
      ticker: 'AAPL',
      market: 'S&P500',
      signal: 'Venda',
      pattern: 'Topo Duplo',
      volume: '2.1x',
      stopLoss: -4.5,
      stopGain: 10.2,
      score: 7.8,
      timestamp: '2025-05-17T11:15:00'
    },
    {
      id: 3,
      ticker: 'BTC',
      market: 'CRYPTO',
      signal: 'Compra',
      pattern: 'Engolfo',
      volume: '3.2x',
      stopLoss: -6.5,
      stopGain: 15.7,
      score: 9.2,
      timestamp: '2025-05-17T12:45:00'
    },
    {
      id: 4,
      ticker: 'VALE3',
      market: 'B3',
      signal: 'Compra',
      pattern: 'Mulher Grávida',
      volume: '1.8x',
      stopLoss: -4.8,
      stopGain: 11.5,
      score: 8.1,
      timestamp: '2025-05-17T13:20:00'
    },
    {
      id: 5,
      ticker: 'MSFT',
      market: 'S&P500',
      signal: 'Venda',
      pattern: 'OCO',
      volume: '1.3x',
      stopLoss: -3.9,
      stopGain: 9.8,
      score: 6.7,
      timestamp: '2025-05-17T14:05:00'
    },
    {
      id: 6,
      ticker: 'ETH',
      market: 'CRYPTO',
      signal: 'Compra',
      pattern: 'Engolfo',
      volume: '2.7x',
      stopLoss: -7.2,
      stopGain: 18.5,
      score: 8.9,
      timestamp: '2025-05-17T14:30:00'
    }
  ];
  
  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ 
        mb: 4, 
        display: 'flex', 
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap'
      }}>
        <Box>
          <Typography variant="h4" component="h1" sx={{ fontWeight: 600, mb: 1 }}>
            Dashboard
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Visão geral dos mercados e sinais de trading
          </Typography>
        </Box>
        
        <Box sx={{ display: 'flex', gap: 2, mt: { xs: 2, md: 0 } }}>
          <Button 
            variant="outlined" 
            startIcon={<Refresh />}
            size="small"
            onClick={() => {
              // Simulando atualização dos dados
              console.log('Atualizando dados do dashboard...');
              // Aqui seria implementada a lógica para atualizar os dados
              // Por exemplo, uma chamada de API ou recarga de dados locais
            }}
          >
            Atualizar
          </Button>
          <Button 
            variant="contained" 
            startIcon={<FilterList />}
            size="small"
            onClick={() => {
              // Simulando abertura de filtros
              console.log('Abrindo filtros do dashboard...');
              // Aqui seria implementada a lógica para abrir modal de filtros
              // ou redirecionar para página de filtros
            }}
          >
            Filtros
          </Button>
        </Box>
      </Box>
      
      <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
        Mercados
      </Typography>
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {marketData.map((market) => (
          <Grid item xs={12} sm={6} md={3} key={market.id}>
            <MarketCard 
              title={market.title}
              value={market.value}
              change={market.change}
              changePercent={market.changePercent}
              icon={market.icon}
            />
          </Grid>
        ))}
      </Grid>
      
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        mb: 2
      }}>
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          Sinais de Trading
        </Typography>
        
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Button 
            variant="text" 
            startIcon={<Search />}
            size="small"
            sx={{ 
              mr: { xs: 2, sm: 1 },
              minWidth: { xs: '100px', sm: 'auto' },
              minHeight: { xs: '44px', sm: 'auto' },
              padding: { xs: '8px 16px', sm: '6px 8px' },
              borderRadius: '8px',
              transition: 'all 0.2s ease-in-out',
              '&:hover': {
                backgroundColor: alpha(theme.palette.primary.main, 0.1),
                transform: 'scale(1.03)'
              },
              '&:active': {
                backgroundColor: alpha(theme.palette.primary.main, 0.2),
                transform: 'scale(0.98)'
              }
            }}
            onClick={() => {
              // Simulando busca de sinais
              console.log('Buscando sinais de trading...');
              // Aqui seria implementada a lógica para buscar sinais
            }}
          >
            Buscar
          </Button>
          <Button 
            variant="text" 
            color="primary"
            sx={{ 
              minWidth: { xs: '100px', sm: 'auto' },
              minHeight: { xs: '44px', sm: 'auto' },
              padding: { xs: '8px 16px', sm: '6px 8px' },
              borderRadius: '8px',
              fontWeight: 'bold',
              transition: 'all 0.2s ease-in-out',
              '&:hover': {
                backgroundColor: alpha(theme.palette.primary.main, 0.1),
                transform: 'scale(1.03)'
              },
              '&:active': {
                backgroundColor: alpha(theme.palette.primary.main, 0.2),
                transform: 'scale(0.98)'
              }
            }}
            onClick={() => {
              // Navegando para página com todos os sinais
              console.log('Navegando para página de todos os sinais...');
              // Aqui seria implementada a navegação para página completa
            }}
          >
            Ver todos
          </Button>
        </Box>
      </Box>
      
      <Grid container spacing={3}>
        {signalData.map((signal) => (
          <Grid item xs={12} sm={6} md={4} key={signal.id}>
            <SignalCard 
              ticker={signal.ticker}
              market={signal.market}
              signal={signal.signal}
              pattern={signal.pattern}
              volume={signal.volume}
              stopLoss={signal.stopLoss}
              stopGain={signal.stopGain}
              score={signal.score}
              timestamp={signal.timestamp}
            />
          </Grid>
        ))}
      </Grid>
      
      <Box sx={{ mt: 4 }}>
        <Paper sx={{ p: 3 }}>
          <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
            Resumo de Performance
          </Typography>
          
          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <Box sx={{ 
                height: 300, 
                bgcolor: alpha(theme.palette.primary.main, 0.05),
                borderRadius: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Typography variant="body1" color="text.secondary">
                  Gráfico de Performance
                </Typography>
              </Box>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <List>
                <ListItem>
                  <ListItemIcon>
                    <TrendingUp color="success" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Taxa de Acerto" 
                    secondary={
                      <Typography variant="body2" className="financial-data" color="success.main">
                        78.5%
                      </Typography>
                    }
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <BarChart color="primary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Retorno Médio" 
                    secondary={
                      <Typography variant="body2" className="financial-data" color="success.main">
                        +12.7%
                      </Typography>
                    }
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <Timeline color="secondary" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Drawdown Máximo" 
                    secondary={
                      <Typography variant="body2" className="financial-data" color="error.main">
                        -4.2%
                      </Typography>
                    }
                  />
                </ListItem>
                <ListItem>
                  <ListItemIcon>
                    <PieChart color="info" />
                  </ListItemIcon>
                  <ListItemText 
                    primary="Relação Risco/Retorno" 
                    secondary={
                      <Typography variant="body2" className="financial-data">
                        1:3.2
                      </Typography>
                    }
                  />
                </ListItem>
              </List>
            </Grid>
          </Grid>
        </Paper>
      </Box>
    </Container>
  );
};

export default Dashboard;
