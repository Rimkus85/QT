/**
 * SettingsPage.js
 * Página de configurações do sistema
 */

import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Switch,
  Divider,
  FormControl,
  FormControlLabel,
  Slider,
  TextField,
  MenuItem,
  Select,
  InputLabel,
  Snackbar,
  Alert,
  Card,
  CardContent,
  CardHeader,
  alpha
} from '@mui/material';
import {
  Brightness4 as DarkModeIcon,
  Brightness7 as LightModeIcon,
  Notifications as NotificationsIcon,
  Language,
  Storage,
  Security,
  Devices,
  Api,
  Refresh
} from '@mui/icons-material';
import { useTheme, ThemeProvider, createTheme } from '@mui/material/styles';
import { useAuth } from '../contexts/AuthContext';
import MainLayout from '../layouts/MainLayout';

const SettingsPage = () => {
  const { user, updateUserData } = useAuth();
  const theme = useTheme();
  
  const [settings, setSettings] = useState({
    theme: 'dark',
    notifications: true,
    twoFactorAuth: false,
    apiKeys: {
      profit: user?.apiKeys?.profit || '',
      binance: user?.apiKeys?.binance || ''
    },
    language: 'pt-BR',
    dataRetention: 90,
    autoRefresh: true
  });
  
  const [loading, setLoading] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState('');
  const [alertSeverity, setAlertSeverity] = useState('info');

  // Manipulador de alteração de configurações
  const handleSettingChange = (setting, value) => {
    setSettings(prevSettings => ({
      ...prevSettings,
      [setting]: value
    }));
  };

  // Manipulador de alteração de chaves de API
  const handleApiKeyChange = (api, value) => {
    setSettings(prevSettings => ({
      ...prevSettings,
      apiKeys: {
        ...prevSettings.apiKeys,
        [api]: value
      }
    }));
  };

  // Salvar configurações
  const handleSaveSettings = async () => {
    setLoading(true);
    
    try {
      // Simulação de salvamento de configurações
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Atualiza dados do usuário (apenas as chaves de API)
      if (user) {
        await updateUserData({
          apiKeys: settings.apiKeys
        });
      }
      
      setAlertMessage('Configurações salvas com sucesso!');
      setAlertSeverity('success');
      setShowAlert(true);
    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
      setAlertMessage('Erro ao salvar configurações. Tente novamente.');
      setAlertSeverity('error');
      setShowAlert(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        {/* Cabeçalho */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom>
            Configurações
          </Typography>
          <Typography variant="subtitle1" color="text.secondary">
            Personalize sua experiência no Quantum Trades.
          </Typography>
        </Box>
        
        <Grid container spacing={3}>
          {/* Configurações de Aparência */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardHeader title="Aparência e Interface" />
              <Divider />
              <CardContent>
                <List>
                  <ListItem>
                    <ListItemIcon>
                      {settings.theme === 'dark' ? <DarkModeIcon /> : <LightModeIcon />}
                    </ListItemIcon>
                    <ListItemText 
                      primary="Tema" 
                      secondary={settings.theme === 'dark' ? 'Escuro' : 'Claro'} 
                    />
                    <Switch
                      edge="end"
                      checked={settings.theme === 'dark'}
                      onChange={(e) => handleSettingChange('theme', e.target.checked ? 'dark' : 'light')}
                    />
                  </ListItem>
                  
                  <Divider variant="inset" component="li" />
                  
                  <ListItem>
                    <ListItemIcon>
                      <NotificationsIcon />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Notificações" 
                      secondary="Receber alertas e notificações" 
                    />
                    <Switch
                      edge="end"
                      checked={settings.notifications}
                      onChange={(e) => handleSettingChange('notifications', e.target.checked)}
                    />
                  </ListItem>
                  
                  <Divider variant="inset" component="li" />
                  
                  <ListItem>
                    <ListItemIcon>
                      <Refresh />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Atualização Automática" 
                      secondary="Atualizar dados automaticamente" 
                    />
                    <Switch
                      edge="end"
                      checked={settings.autoRefresh}
                      onChange={(e) => handleSettingChange('autoRefresh', e.target.checked)}
                    />
                  </ListItem>
                  
                  <Divider variant="inset" component="li" />
                  
                  <ListItem>
                    <ListItemText 
                      primary="Retenção de Dados" 
                      secondary={`${settings.dataRetention} dias`} 
                    />
                    <Box sx={{ width: 200 }}>
                      <Slider
                        value={settings.dataRetention}
                        min={30}
                        max={365}
                        step={30}
                        marks={[
                          { value: 30, label: '30d' },
                          { value: 180, label: '180d' },
                          { value: 365, label: '365d' }
                        ]}
                        onChange={(e, value) => handleSettingChange('dataRetention', value)}
                      />
                    </Box>
                  </ListItem>
                </List>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Configurações de Segurança e APIs */}
          <Grid item xs={12} md={6}>
            <Card>
              <CardHeader title="Segurança e Integrações" />
              <Divider />
              <CardContent>
                <List>
                  <ListItem>
                    <ListItemIcon>
                      <Security />
                    </ListItemIcon>
                    <ListItemText 
                      primary="Autenticação de Dois Fatores" 
                      secondary="Aumenta a segurança da sua conta" 
                    />
                    <Switch
                      edge="end"
                      checked={settings.twoFactorAuth}
                      onChange={(e) => handleSettingChange('twoFactorAuth', e.target.checked)}
                    />
                  </ListItem>
                  
                  <Divider variant="inset" component="li" />
                  
                  <ListItem>
                    <ListItemIcon>
                      <Api />
                    </ListItemIcon>
                    <ListItemText 
                      primary="API Profit" 
                      secondary="Chave para integração com Profit" 
                    />
                  </ListItem>
                  <ListItem sx={{ pl: 9 }}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      size="small"
                      type="password"
                      value={settings.apiKeys.profit}
                      onChange={(e) => handleApiKeyChange('profit', e.target.value)}
                      placeholder="Insira sua chave de API Profit"
                    />
                  </ListItem>
                  
                  <Divider variant="inset" component="li" />
                  
                  <ListItem>
                    <ListItemIcon>
                      <Api />
                    </ListItemIcon>
                    <ListItemText 
                      primary="API Binance" 
                      secondary="Chave para integração com Binance" 
                    />
                  </ListItem>
                  <ListItem sx={{ pl: 9 }}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      size="small"
                      type="password"
                      value={settings.apiKeys.binance}
                      onChange={(e) => handleApiKeyChange('binance', e.target.value)}
                      placeholder="Insira sua chave de API Binance"
                    />
                  </ListItem>
                </List>
              </CardContent>
            </Card>
          </Grid>
          
          {/* Botão de Salvar */}
          <Grid item xs={12}>
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
              <Button
                variant="contained"
                color="primary"
                size="large"
                onClick={handleSaveSettings}
                disabled={loading}
              >
                {loading ? 'Salvando...' : 'Salvar Configurações'}
              </Button>
            </Box>
          </Grid>
        </Grid>
        
        <Snackbar
          open={showAlert}
          autoHideDuration={6000}
          onClose={() => setShowAlert(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert 
            onClose={() => setShowAlert(false)} 
            severity={alertSeverity} 
            sx={{ width: '100%' }}
          >
            {alertMessage}
          </Alert>
        </Snackbar>
      </Container>
    </MainLayout>
  );
};

export default SettingsPage;
