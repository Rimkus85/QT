/**
 * LoginPage.js
 * Página de login do Quantum Trades com funcionalidade de recuperação de senha
 * Versão atualizada com validação de formato de e-mail e link para recuperação de senha
 */

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Box, 
  TextField, 
  Button, 
  Typography, 
  Container, 
  Paper,
  CircularProgress,
  Alert,
  Grid
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';

// Logo
import LogoQuantumTrades from '../assets/logo-quantum-trades.png';

// Componente de recuperação de senha
import ForgotPasswordForm from '../components/ForgotPasswordForm';

/**
 * Página de login do Quantum Trades
 * 
 * @returns {React.ReactElement} Página de login
 */
const LoginPage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const navigate = useNavigate();
  
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  
  // Validação de formato de e-mail
  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validação dos campos
    if (!username || !password) {
      setError('Por favor, preencha todos os campos.');
      return;
    }
    
    // Validação do formato de e-mail
    if (!isValidEmail(username)) {
      setError('Por favor, informe um e-mail válido.');
      return;
    }
    
    setError('');
    setIsLoading(true);
    
    // Simulação de login (mock)
    setTimeout(() => {
      setIsLoading(false);
      
      // Credenciais de teste
      if (username === 'Rimkus' && password === 'password123') {
        // Login bem-sucedido
        localStorage.setItem('isAuthenticated', 'true');
        navigate('/dashboard');
      } else {
        // Login falhou
        setError('Credenciais inválidas. Tente novamente.');
      }
    }, 1000);
  };
  
  // Alternar entre login e recuperação de senha
  const toggleForgotPassword = () => {
    setShowForgotPassword(!showForgotPassword);
  };
  
  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#10263d',
        py: 4
      }}
    >
      <Container maxWidth="sm">
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            mb: 4
          }}
        >
          <img 
            src={LogoQuantumTrades} 
            alt="Quantum Trades" 
            style={{ 
              height: isMobile ? 60 : 80,
              marginBottom: theme.spacing(4)
            }} 
          />
        </Box>
        
        {showForgotPassword ? (
          <ForgotPasswordForm />
        ) : (
          <Paper 
            elevation={3}
            sx={{ 
              p: { xs: 3, sm: 4 },
              borderRadius: 2
            }}
          >
            <Typography 
              variant={isMobile ? "h5" : "h4"} 
              component="h1" 
              align="center"
              sx={{ 
                mb: 3,
                fontWeight: 600,
                color: theme.palette.text.primary
              }}
            >
              Acesso ao Sistema
            </Typography>
            
            {error && (
              <Alert severity="error" sx={{ mb: 2 }}>
                {error}
              </Alert>
            )}
            
            <Box component="form" onSubmit={handleSubmit} noValidate>
              <TextField
                margin="normal"
                required
                fullWidth
                id="username"
                label="E-mail"
                name="username"
                autoComplete="email"
                autoFocus
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={isLoading}
                sx={{ mb: 2 }}
              />
              
              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="Senha"
                type="password"
                id="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
                sx={{ mb: 3 }}
              />
              
              <Button
                type="submit"
                fullWidth
                variant="contained"
                disabled={isLoading}
                sx={{ 
                  py: 1.5,
                  backgroundColor: theme.palette.primary.main,
                  '&:hover': {
                    backgroundColor: theme.palette.primary.dark,
                  }
                }}
              >
                {isLoading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : (
                  'Entrar'
                )}
              </Button>
              
              <Grid container sx={{ mt: 3 }}>
                <Grid item xs>
                  <Button 
                    onClick={toggleForgotPassword}
                    sx={{ 
                      textTransform: 'none',
                      color: theme.palette.primary.main
                    }}
                  >
                    Esqueceu sua senha?
                  </Button>
                </Grid>
                <Grid item>
                  <Button 
                    component={Link} 
                    to="/register"
                    sx={{ 
                      textTransform: 'none',
                      color: theme.palette.primary.main
                    }}
                  >
                    Criar conta
                  </Button>
                </Grid>
              </Grid>
            </Box>
          </Paper>
        )}
      </Container>
    </Box>
  );
};

export default LoginPage;
