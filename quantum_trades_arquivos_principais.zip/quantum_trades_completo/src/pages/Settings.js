import React from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  Card, 
  CardContent, 
  CardHeader,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  IconButton,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Slider,
  Tabs,
  Tab,
  useTheme,
  alpha
} from '@mui/material';
import { 
  Settings as SettingsIcon,
  Notifications,
  Security,
  AccountCircle,
  Palette,
  Language,
  Storage,
  CloudSync,
  Devices,
  Save,
  Refresh
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { colors } from '../theme';

// Componente de TabPanel para as abas de configurações
const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`settings-tabpanel-${index}`}
      aria-labelledby={`settings-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Função para criar propriedades de acessibilidade para as abas
const a11yProps = (index) => {
  return {
    id: `settings-tab-${index}`,
    'aria-controls': `settings-tabpanel-${index}`,
  };
};

// Componente principal de Configurações
const SettingsPage = () => {
  const { user } = useAuth();
  const theme = useTheme();
  const [tabValue, setTabValue] = React.useState(0);
  
  // Estado para as configurações
  const [settings, setSettings] = React.useState({
    notifications: {
      email: true,
      push: true,
      sms: false,
      tradeAlerts: true,
      marketUpdates: true,
      systemAlerts: true
    },
    appearance: {
      theme: 'dark',
      density: 'comfortable',
      chartStyle: 'candles',
      showVolume: true,
      showIndicators: true
    },
    trading: {
      defaultRiskPercentage: 2,
      autoStopLoss: true,
      autoTakeProfit: true,
      confirmTrades: true,
      tradingHours: 'all',
      maxSimultaneousTrades: 5
    },
    integration: {
      profitChartEnabled: true,
      binanceEnabled: true,
      autoSync: true,
      syncInterval: 5
    },
    security: {
      twoFactorAuth: true,
      sessionTimeout: 30,
      ipRestriction: false,
      tradeConfirmation: 'all'
    }
  });
  
  // Manipulador de mudança de aba
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  // Manipulador de mudança de configurações
  const handleSettingChange = (section, setting, value) => {
    setSettings({
      ...settings,
      [section]: {
        ...settings[section],
        [setting]: value
      }
    });
  };
  
  // Manipulador de salvamento de configurações
  const handleSaveSettings = () => {
    // Aqui seria implementada a lógica para salvar as configurações no backend
    console.log('Configurações salvas:', settings);
    // Mostrar notificação de sucesso
  };
  
  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ 
        mb: 4, 
        display: 'flex', 
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Box>
          <Typography variant="h4" component="h1" sx={{ fontWeight: 600, mb: 1 }}>
            Configurações
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Personalize sua experiência no Quantum Trades
          </Typography>
        </Box>
        
        <Button 
          variant="contained" 
          startIcon={<Save />}
          onClick={handleSaveSettings}
        >
          Salvar Alterações
        </Button>
      </Box>
      
      <Paper sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            aria-label="configurações"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab 
              icon={<AccountCircle />} 
              label="Conta" 
              {...a11yProps(0)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<Notifications />} 
              label="Notificações" 
              {...a11yProps(1)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<Palette />} 
              label="Aparência" 
              {...a11yProps(2)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<SettingsIcon />} 
              label="Trading" 
              {...a11yProps(3)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<CloudSync />} 
              label="Integrações" 
              {...a11yProps(4)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<Security />} 
              label="Segurança" 
              {...a11yProps(5)} 
              sx={{ textTransform: 'none' }}
            />
          </Tabs>
        </Box>
        
        {/* Aba de Conta */}
        <TabPanel value={tabValue} index={0}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card>
                <CardHeader title="Informações Pessoais" />
                <Divider />
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Nome"
                        defaultValue={user?.name || ""}
                        variant="outlined"
                        size="small"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Email"
                        defaultValue={user?.email || ""}
                        variant="outlined"
                        size="small"
                        disabled
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <TextField
                        fullWidth
                        label="Telefone"
                        defaultValue={user?.phone || ""}
                        variant="outlined"
                        size="small"
                      />
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card>
                <CardHeader title="Preferências de Conta" />
                <Divider />
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Idioma</InputLabel>
                        <Select
                          value="pt-BR"
                          label="Idioma"
                        >
                          <MenuItem value="pt-BR">Português (Brasil)</MenuItem>
                          <MenuItem value="en-US">English (US)</MenuItem>
                          <MenuItem value="es">Español</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Fuso Horário</InputLabel>
                        <Select
                          value="America/Sao_Paulo"
                          label="Fuso Horário"
                        >
                          <MenuItem value="America/Sao_Paulo">Brasília (GMT-3)</MenuItem>
                          <MenuItem value="America/New_York">New York (GMT-4)</MenuItem>
                          <MenuItem value="Europe/London">London (GMT+1)</MenuItem>
                          <MenuItem value="Asia/Tokyo">Tokyo (GMT+9)</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Formato de Data</InputLabel>
                        <Select
                          value="DD/MM/YYYY"
                          label="Formato de Data"
                        >
                          <MenuItem value="DD/MM/YYYY">DD/MM/YYYY</MenuItem>
                          <MenuItem value="MM/DD/YYYY">MM/DD/YYYY</MenuItem>
                          <MenuItem value="YYYY-MM-DD">YYYY-MM-DD</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </TabPanel>
        
        {/* Aba de Notificações */}
        <TabPanel value={tabValue} index={1}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card>
                <CardHeader title="Canais de Notificação" />
                <Divider />
                <CardContent>
                  <List>
                    <ListItem>
                      <ListItemText 
                        primary="Notificações por Email" 
                        secondary="Receba alertas e resumos por email"
                      />
                      <Switch
                        checked={settings.notifications.email}
                        onChange={(e) => handleSettingChange('notifications', 'email', e.target.checked)}
                        inputProps={{ 'aria-label': 'notificações por email' }}
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Notificações Push" 
                        secondary="Receba alertas em tempo real no navegador"
                      />
                      <Switch
                        checked={settings.notifications.push}
                        onChange={(e) => handleSettingChange('notifications', 'push', e.target.checked)}
                        inputProps={{ 'aria-label': 'notificações push' }}
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Notificações SMS" 
                        secondary="Receba alertas críticos por mensagem de texto"
                      />
                      <Switch
                        checked={settings.notifications.sms}
                        onChange={(e) => handleSettingChange('notifications', 'sms', e.target.checked)}
                        inputProps={{ 'aria-label': 'notificações sms' }}
                      />
                    </ListItem>
                  </List>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card>
                <CardHeader title="Tipos de Notificação" />
                <Divider />
                <CardContent>
                  <List>
                    <ListItem>
                      <ListItemText 
                        primary="Alertas de Trading" 
                        secondary="Sinais de compra/venda e oportunidades"
                      />
                      <Switch
                        checked={settings.notifications.tradeAlerts}
                        onChange={(e) => handleSettingChange('notifications', 'tradeAlerts', e.target.checked)}
                        inputProps={{ 'aria-label': 'alertas de trading' }}
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Atualizações de Mercado" 
                        secondary="Mudanças significativas nos mercados"
                      />
                      <Switch
                        checked={settings.notifications.marketUpdates}
                        onChange={(e) => handleSettingChange('notifications', 'marketUpdates', e.target.checked)}
                        inputProps={{ 'aria-label': 'atualizações de mercado' }}
                      />
                    </ListItem>
                    <ListItem>
                      <ListItemText 
                        primary="Alertas do Sistema" 
                        secondary="Manutenção, atualizações e segurança"
                      />
                      <Switch
                        checked={settings.notifications.systemAlerts}
                        onChange={(e) => handleSettingChange('notifications', 'systemAlerts', e.target.checked)}
                        inputProps={{ 'aria-label': 'alertas do sistema' }}
                      />
                    </ListItem>
                  </List>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </TabPanel>
        
        {/* Restante do código... */}
      </Paper>
    </Container>
  );
};

export default SettingsPage;
