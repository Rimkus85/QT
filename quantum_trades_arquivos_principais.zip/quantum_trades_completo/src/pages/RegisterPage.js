/**
 * RegisterPage.js
 * Página de cadastro completa para o Quantum Trades
 */

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Box, 
  TextField, 
  Button, 
  Typography, 
  Container, 
  Paper,
  CircularProgress,
  Alert,
  Grid,
  Stepper,
  Step,
  StepLabel,
  FormControlLabel,
  Checkbox,
  InputAdornment,
  IconButton
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import useMediaQuery from '@mui/material/useMediaQuery';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

// Logo
import LogoQuantumTrades from '../assets/logo-quantum-trades.png';

/**
 * Página de cadastro do Quantum Trades
 * 
 * @returns {React.ReactElement} Página de cadastro
 */
const RegisterPage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const navigate = useNavigate();
  
  // Estado para controle do stepper
  const [activeStep, setActiveStep] = useState(0);
  const steps = ['Informações pessoais', 'Dados de acesso', 'Confirmação'];
  
  // Estados para os campos do formulário
  const [formData, setFormData] = useState({
    nome: '',
    sobrenome: '',
    email: '',
    telefone: '',
    cpf: '',
    senha: '',
    confirmarSenha: '',
    aceitarTermos: false
  });
  
  // Estados para controle de UI
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [registrationComplete, setRegistrationComplete] = useState(false);
  
  // Validações
  const [validations, setValidations] = useState({
    nome: true,
    sobrenome: true,
    email: true,
    telefone: true,
    cpf: true,
    senha: true,
    confirmarSenha: true,
    aceitarTermos: true
  });
  
  // Funções de validação
  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  
  const isValidCPF = (cpf) => {
    // Implementação simplificada de validação de CPF
    const cpfClean = cpf.replace(/[^\d]/g, '');
    return cpfClean.length === 11;
  };
  
  const isValidPhone = (phone) => {
    // Implementação simplificada de validação de telefone
    const phoneClean = phone.replace(/[^\d]/g, '');
    return phoneClean.length >= 10;
  };
  
  const isStrongPassword = (password) => {
    // Senha deve ter pelo menos 8 caracteres, uma letra maiúscula, uma minúscula e um número
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    return passwordRegex.test(password);
  };
  
  // Manipuladores de eventos
  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    const isCheckbox = name === 'aceitarTermos';
    
    setFormData({
      ...formData,
      [name]: isCheckbox ? checked : value
    });
    
    // Limpar erro ao editar campo
    setError('');
  };
  
  const handleNext = () => {
    // Validar etapa atual antes de avançar
    if (activeStep === 0) {
      // Validar informações pessoais
      const isNomeValid = formData.nome.trim().length >= 2;
      const isSobrenomeValid = formData.sobrenome.trim().length >= 2;
      const isEmailValid = isValidEmail(formData.email);
      const isTelefoneValid = isValidPhone(formData.telefone);
      const isCpfValid = isValidCPF(formData.cpf);
      
      setValidations({
        ...validations,
        nome: isNomeValid,
        sobrenome: isSobrenomeValid,
        email: isEmailValid,
        telefone: isTelefoneValid,
        cpf: isCpfValid
      });
      
      if (!isNomeValid || !isSobrenomeValid || !isEmailValid || !isTelefoneValid || !isCpfValid) {
        setError('Por favor, corrija os campos destacados.');
        return;
      }
    } else if (activeStep === 1) {
      // Validar dados de acesso
      const isSenhaValid = isStrongPassword(formData.senha);
      const isConfirmarSenhaValid = formData.senha === formData.confirmarSenha;
      
      setValidations({
        ...validations,
        senha: isSenhaValid,
        confirmarSenha: isConfirmarSenhaValid
      });
      
      if (!isSenhaValid || !isConfirmarSenhaValid) {
        setError(
          !isSenhaValid 
            ? 'A senha deve ter pelo menos 8 caracteres, uma letra maiúscula, uma minúscula e um número.' 
            : 'As senhas não coincidem.'
        );
        return;
      }
    }
    
    setError('');
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };
  
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
    setError('');
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validar aceitação dos termos
    if (!formData.aceitarTermos) {
      setValidations({
        ...validations,
        aceitarTermos: false
      });
      setError('Você precisa aceitar os termos de uso para continuar.');
      return;
    }
    
    setError('');
    setIsLoading(true);
    
    // Simulação de cadastro (mock)
    setTimeout(() => {
      setIsLoading(false);
      setRegistrationComplete(true);
    }, 1500);
  };
  
  const handleBackToLogin = () => {
    navigate('/login');
  };
  
  // Formatação de campos
  const formatCPF = (value) => {
    const cpfClean = value.replace(/[^\d]/g, '');
    if (cpfClean.length <= 3) return cpfClean;
    if (cpfClean.length <= 6) return `${cpfClean.slice(0, 3)}.${cpfClean.slice(3)}`;
    if (cpfClean.length <= 9) return `${cpfClean.slice(0, 3)}.${cpfClean.slice(3, 6)}.${cpfClean.slice(6)}`;
    return `${cpfClean.slice(0, 3)}.${cpfClean.slice(3, 6)}.${cpfClean.slice(6, 9)}-${cpfClean.slice(9, 11)}`;
  };
  
  const formatPhone = (value) => {
    const phoneClean = value.replace(/[^\d]/g, '');
    if (phoneClean.length <= 2) return phoneClean;
    if (phoneClean.length <= 6) return `(${phoneClean.slice(0, 2)}) ${phoneClean.slice(2)}`;
    return `(${phoneClean.slice(0, 2)}) ${phoneClean.slice(2, 7)}-${phoneClean.slice(7, 11)}`;
  };
  
  // Renderização dos passos do formulário
  const renderStepContent = (step) => {
    switch (step) {
      case 0:
        return (
          <>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="nome"
                  label="Nome"
                  name="nome"
                  value={formData.nome}
                  onChange={handleChange}
                  error={!validations.nome}
                  helperText={!validations.nome ? "Nome é obrigatório" : ""}
                  disabled={isLoading}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="sobrenome"
                  label="Sobrenome"
                  name="sobrenome"
                  value={formData.sobrenome}
                  onChange={handleChange}
                  error={!validations.sobrenome}
                  helperText={!validations.sobrenome ? "Sobrenome é obrigatório" : ""}
                  disabled={isLoading}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="email"
                  label="E-mail"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  error={!validations.email}
                  helperText={!validations.email ? "E-mail inválido" : ""}
                  disabled={isLoading}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="telefone"
                  label="Telefone"
                  name="telefone"
                  value={formData.telefone}
                  onChange={(e) => {
                    const formattedValue = formatPhone(e.target.value);
                    setFormData({
                      ...formData,
                      telefone: formattedValue
                    });
                  }}
                  error={!validations.telefone}
                  helperText={!validations.telefone ? "Telefone inválido" : ""}
                  disabled={isLoading}
                  inputProps={{ maxLength: 15 }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  id="cpf"
                  label="CPF"
                  name="cpf"
                  value={formData.cpf}
                  onChange={(e) => {
                    const formattedValue = formatCPF(e.target.value);
                    setFormData({
                      ...formData,
                      cpf: formattedValue
                    });
                  }}
                  error={!validations.cpf}
                  helperText={!validations.cpf ? "CPF inválido" : ""}
                  disabled={isLoading}
                  inputProps={{ maxLength: 14 }}
                />
              </Grid>
            </Grid>
          </>
        );
      case 1:
        return (
          <>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="senha"
                  label="Senha"
                  name="senha"
                  type={showPassword ? 'text' : 'password'}
                  value={formData.senha}
                  onChange={handleChange}
                  error={!validations.senha}
                  helperText={!validations.senha ? "A senha deve ter pelo menos 8 caracteres, uma letra maiúscula, uma minúscula e um número" : ""}
                  disabled={isLoading}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={() => setShowPassword(!showPassword)}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    )
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="confirmarSenha"
                  label="Confirmar Senha"
                  name="confirmarSenha"
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={formData.confirmarSenha}
                  onChange={handleChange}
                  error={!validations.confirmarSenha}
                  helperText={!validations.confirmarSenha ? "As senhas não coincidem" : ""}
                  disabled={isLoading}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          edge="end"
                        >
                          {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    )
                  }}
                />
              </Grid>
            </Grid>
          </>
        );
      case 2:
        return (
          <>
            <Typography variant="h6" gutterBottom>
              Confirme seus dados
            </Typography>
            
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Nome completo</Typography>
                <Typography variant="body1">{`${formData.nome} ${formData.sobrenome}`}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">E-mail</Typography>
                <Typography variant="body1">{formData.email}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">Telefone</Typography>
                <Typography variant="body1">{formData.telefone}</Typography>
              </Grid>
              <Grid item xs={12} sm={6}>
                <Typography variant="subtitle2">CPF</Typography>
                <Typography variant="body1">{formData.cpf}</Typography>
              </Grid>
            </Grid>
            
            <Box sx={{ mt: 3 }}>
              <FormControlLabel
                control={
                  <Checkbox
                    name="aceitarTermos"
                    checked={formData.aceitarTermos}
                    onChange={handleChange}
                    color="primary"
                    disabled={isLoading}
                  />
                }
                label="Li e aceito os termos de uso e política de privacidade"
                sx={{ color: !validations.aceitarTermos ? 'error.main' : 'inherit' }}
              />
            </Box>
          </>
        );
      default:
        return null;
    }
  };
  
  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#10263d',
        py: 4
      }}
    >
      <Container maxWidth="md">
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            mb: 4
          }}
        >
          <img 
            src={LogoQuantumTrades} 
            alt="Quantum Trades" 
            style={{ 
              height: isMobile ? 60 : 80,
              marginBottom: theme.spacing(4)
            }} 
          />
        </Box>
        
        <Paper 
          elevation={3}
          sx={{ 
            p: { xs: 3, sm: 4 },
            borderRadius: 2
          }}
        >
          {registrationComplete ? (
            <Box sx={{ textAlign: 'center' }}>
              <Typography variant="h5" component="h1" gutterBottom>
                Cadastro realizado com sucesso!
              </Typography>
              
              <Typography variant="body1" sx={{ mb: 3 }}>
                Enviamos um e-mail de confirmação para {formData.email}.
                Por favor, verifique sua caixa de entrada e confirme seu cadastro para ativar sua conta.
              </Typography>
              
              <Button
                variant="contained"
                color="primary"
                onClick={handleBackToLogin}
                fullWidth
                sx={{ mt: 2 }}
              >
                Ir para o login
              </Button>
            </Box>
          ) : (
            <>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                <Button
                  startIcon={<ArrowBackIcon />}
                  onClick={handleBackToLogin}
                  sx={{ mr: 2 }}
                >
                  Voltar
                </Button>
                
                <Typography 
                  variant={isMobile ? "h5" : "h4"} 
                  component="h1"
                  sx={{ fontWeight: 600 }}
                >
                  Criar conta
                </Typography>
              </Box>
              
              <Stepper activeStep={activeStep} alternativeLabel sx={{ mb: 4 }}>
                {steps.map((label) => (
                  <Step key={label}>
                    <StepLabel>{label}</StepLabel>
                  </Step>
                ))}
              </Stepper>
              
              {error && (
                <Alert severity="error" sx={{ mb: 3 }}>
                  {error}
                </Alert>
              )}
              
              <Box component="form" onSubmit={handleSubmit} noValidate>
                {renderStepContent(activeStep)}
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
                  <Button
                    disabled={activeStep === 0 || isLoading}
                    onClick={handleBack}
                    variant="outlined"
                  >
                    Voltar
                  </Button>
                  
                  {activeStep === steps.length - 1 ? (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={handleSubmit}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <CircularProgress size={24} color="inherit" />
                      ) : (
                        'Finalizar cadastro'
                      )}
                    </Button>
                  ) : (
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={handleNext}
                      disabled={isLoading}
                    >
                      Próximo
                    </Button>
                  )}
                </Box>
              </Box>
            </>
          )}
        </Paper>
      </Container>
    </Box>
  );
};

export default RegisterPage;
