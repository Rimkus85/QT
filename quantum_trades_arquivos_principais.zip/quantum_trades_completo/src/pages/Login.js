import React, { useState } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  TextField,
  Alert,
  Avatar,
  CssBaseline,
  Link,
  FormControlLabel,
  Checkbox,
  CircularProgress
} from '@mui/material';
import { LockOutlined } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const navigate = useNavigate();
  const { login } = useAuth();
  
  // Função de login otimizada para dispositivos móveis
  const handleSubmit = async (e) => {
    e.preventDefault();
    e.stopPropagation(); // Previne propagação de eventos
    
    if (!username || !password) {
      setError('Por favor, preencha todos os campos.');
      return;
    }
    
    try {
      setError('');
      setLoading(true);
      
      // Simplificando o fluxo de autenticação para maior compatibilidade
      await login(username, password);
      
      // Redirecionamento após login bem-sucedido
      window.location.href = '/'; // Redirecionando para a rota raiz que contém o dashboard
    } catch (error) {
      console.error('Login error:', error);
      setError('Falha no login. Verifique suas credenciais.');
    } finally {
      setLoading(false);
    }
  };
  
  // Manipulador alternativo para cliques em dispositivos móveis
  const handleLoginClick = () => {
    if (!username || !password) {
      setError('Por favor, preencha todos os campos.');
      return;
    }
    
    setError('');
    setLoading(true);
    
    // Usando setTimeout para simular o processo assíncrono
    setTimeout(() => {
      try {
        // Login direto para o usuário administrador
        if (username === 'Rimkus' && password === 'password123') {
          const userData = {
            id: 1,
            username: 'Rimkus',
            isAdmin: true,
            name: 'Rimkus',
            email: 'rimkus@example.com'
          };
          
          // Armazenamento em localStorage com tratamento de erro
          try {
            localStorage.setItem('quantum_trades_user', JSON.stringify(userData));
            // Fallback para sessionStorage se localStorage falhar
          } catch (e) {
            console.error('localStorage error:', e);
            sessionStorage.setItem('quantum_trades_user', JSON.stringify(userData));
          }
          
          // Redirecionamento direto
          window.location.href = '/'; // Redirecionando para a rota raiz que contém o dashboard
        } else {
          setError('Falha no login. Verifique suas credenciais.');
          setLoading(false);
        }
      } catch (error) {
        console.error('Login error:', error);
        setError('Ocorreu um erro durante o login. Tente novamente.');
        setLoading(false);
      }
    }, 1000);
  };
  
  return (
    <Container component="main" maxWidth="xs" sx={{ 
      display: 'flex',
      flexDirection: 'column',
      minHeight: '100vh',
      justifyContent: 'center',
      py: 4
    }}>
      <CssBaseline />
      <Paper
        elevation={3}
        sx={{
          p: 4,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          borderRadius: 2
        }}
      >
        <Box sx={{ 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center',
          mb: 2
        }}>
          <img 
            src="/logo_quantum_trades.png" 
            alt="Quantum Trades Logo" 
            style={{ 
              width: '80px', 
              height: '80px', 
              marginBottom: '16px' 
            }} 
          />
          <Typography 
            component="h1" 
            variant="h5" 
            sx={{ 
              color: 'gold.main',
              fontWeight: 'bold',
              textShadow: '0 0 10px rgba(232, 193, 76, 0.7)'
            }}
          >
            Quantum Trades
          </Typography>
        </Box>
        
        {error && (
          <Alert severity="error" sx={{ mt: 2, width: '100%', mb: 2 }}>
            {error}
          </Alert>
        )}
        
        <Box component="form" onSubmit={handleSubmit} noValidate sx={{ width: '100%' }}>
          <TextField
            margin="normal"
            required
            fullWidth
            id="username"
            label="Nome de Usuário"
            name="username"
            autoComplete="username"
            autoFocus
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            inputProps={{ 
              autoCapitalize: 'none',
              autoCorrect: 'off'
            }}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Senha"
            type="password"
            id="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label="Lembrar-me"
          />
          
          {/* Botão de submit do formulário */}
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2, py: 1.5 }}
            disabled={loading}
          >
            {loading ? (
              <CircularProgress size={24} color="inherit" />
            ) : (
              'Entrar'
            )}
          </Button>
          
          {/* Botão alternativo com onClick para dispositivos móveis */}
          <Button
            fullWidth
            variant="outlined"
            sx={{ mb: 2, py: 1.5 }}
            disabled={loading}
            onClick={handleLoginClick}
          >
            {loading ? (
              <CircularProgress size={24} color="inherit" />
            ) : (
              'Entrar (Alternativo)'
            )}
          </Button>
          
          <Grid container>
            <Grid item xs>
              <Link href="#" variant="body2">
                Esqueceu a senha?
              </Link>
            </Grid>
            <Grid item>
              <Link href="#" variant="body2">
                {"Não tem uma conta? Entre em contato"}
              </Link>
            </Grid>
          </Grid>
        </Box>
      </Paper>
      <Box sx={{ mt: 4, textAlign: 'center' }}>
        <Typography variant="body2" color="text.secondary">
          {'Copyright © '}
          <Link color="inherit" href="#">
            Quantum Trades
          </Link>{' '}
          {new Date().getFullYear()}
          {'.'}
        </Typography>
      </Box>
    </Container>
  );
};

export default Login;
