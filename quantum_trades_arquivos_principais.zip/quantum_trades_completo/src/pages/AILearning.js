import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Container, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  Card, 
  CardContent, 
  CardHeader,
  Divider,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Switch,
  FormControlLabel,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Tooltip,
  useTheme,
  alpha,
  LinearProgress,
  Slider
} from '@mui/material';
import { 
  Code,
  PlayArrow,
  Stop,
  Save,
  Refresh,
  Settings,
  Info,
  ArrowUpward,
  ArrowDownward,
  History,
  BarChart,
  FilterList,
  Search,
  Delete,
  Edit,
  Psychology,
  Autorenew,
  BubbleChart,
  Timeline,
  TrendingUp,
  TrendingDown
} from '@mui/icons-material';
import { useAuth } from '../contexts/AuthContext';
import { colors } from '../theme';

// Componente de TabPanel para as abas
const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`ai-learning-tabpanel-${index}`}
      aria-labelledby={`ai-learning-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ py: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Função para criar propriedades de acessibilidade para as abas
const a11yProps = (index) => {
  return {
    id: `ai-learning-tab-${index}`,
    'aria-controls': `ai-learning-tabpanel-${index}`,
  };
};

// Componente principal de Aprendizado de IA
const AILearning = () => {
  const { user } = useAuth();
  const theme = useTheme();
  const [tabValue, setTabValue] = useState(0);
  
  // Estado para configurações de aprendizado
  const [learningSettings, setLearningSettings] = useState({
    dataSource: 'all',
    timeframe: '1d',
    indicators: ['sma', 'ema', 'rsi', 'macd'],
    patternRecognition: true,
    sentimentAnalysis: true,
    fundamentalData: false,
    learningRate: 0.01,
    epochs: 1000,
    batchSize: 32,
    validationSplit: 0.2,
    optimizer: 'adam'
  });
  
  // Estado para modelos de IA
  const [aiModels, setAiModels] = useState([
    {
      id: 1,
      name: 'Quantum Neural Network',
      type: 'deep-learning',
      accuracy: 78.5,
      lastTrained: '2025-05-15T14:30:00',
      status: 'active',
      markets: ['B3', 'S&P500'],
      description: 'Modelo de rede neural profunda otimizado para detecção de padrões em séries temporais financeiras.'
    },
    {
      id: 2,
      name: 'Adaptive Ensemble',
      type: 'ensemble',
      accuracy: 82.3,
      lastTrained: '2025-05-16T09:45:00',
      status: 'active',
      markets: ['B3', 'CRYPTO'],
      description: 'Conjunto adaptativo de modelos que combina diferentes algoritmos para maximizar a precisão preditiva.'
    },
    {
      id: 3,
      name: 'Sentiment Analyzer',
      type: 'nlp',
      accuracy: 71.8,
      lastTrained: '2025-05-14T16:20:00',
      status: 'training',
      markets: ['S&P500', 'CRYPTO'],
      description: 'Modelo de processamento de linguagem natural para análise de sentimento de notícias e redes sociais.'
    }
  ]);
  
  // Estado para histórico de treinamento
  const [trainingHistory, setTrainingHistory] = useState([
    {
      id: 1,
      modelId: 1,
      modelName: 'Quantum Neural Network',
      startTime: '2025-05-15T12:15:00',
      endTime: '2025-05-15T14:30:00',
      epochs: 1000,
      initialAccuracy: 72.1,
      finalAccuracy: 78.5,
      status: 'completed',
      notes: 'Aumento significativo na precisão após ajuste de hiperparâmetros.'
    },
    {
      id: 2,
      modelId: 2,
      modelName: 'Adaptive Ensemble',
      startTime: '2025-05-16T08:00:00',
      endTime: '2025-05-16T09:45:00',
      epochs: 800,
      initialAccuracy: 79.8,
      finalAccuracy: 82.3,
      status: 'completed',
      notes: 'Adição de novos indicadores técnicos melhorou a performance.'
    },
    {
      id: 3,
      modelId: 3,
      modelName: 'Sentiment Analyzer',
      startTime: '2025-05-17T15:30:00',
      endTime: null,
      epochs: 1200,
      initialAccuracy: 71.8,
      finalAccuracy: null,
      status: 'in-progress',
      notes: 'Treinamento com conjunto de dados ampliado incluindo tweets e notícias recentes.'
    }
  ]);
  
  // Manipulador de mudança de aba
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  // Manipulador de mudança de configurações de aprendizado
  const handleLearningSettingChange = (setting, value) => {
    setLearningSettings({
      ...learningSettings,
      [setting]: value
    });
  };
  
  // Manipulador para iniciar treinamento
  const handleStartTraining = (modelId) => {
    // Aqui seria implementada a lógica para iniciar o treinamento do modelo
    console.log(`Iniciando treinamento do modelo ${modelId} com configurações:`, learningSettings);
    
    // Atualizar status do modelo para "training"
    setAiModels(aiModels.map(model => 
      model.id === modelId ? { ...model, status: 'training' } : model
    ));
    
    // Adicionar novo registro ao histórico de treinamento
    const newTrainingRecord = {
      id: trainingHistory.length + 1,
      modelId,
      modelName: aiModels.find(m => m.id === modelId)?.name || '',
      startTime: new Date().toISOString(),
      endTime: null,
      epochs: learningSettings.epochs,
      initialAccuracy: aiModels.find(m => m.id === modelId)?.accuracy || 0,
      finalAccuracy: null,
      status: 'in-progress',
      notes: 'Treinamento iniciado automaticamente.'
    };
    
    setTrainingHistory([...trainingHistory, newTrainingRecord]);
  };
  
  // Manipulador para parar treinamento
  const handleStopTraining = (modelId) => {
    // Aqui seria implementada a lógica para parar o treinamento do modelo
    console.log(`Parando treinamento do modelo ${modelId}`);
    
    // Atualizar status do modelo para "active"
    setAiModels(aiModels.map(model => 
      model.id === modelId ? { ...model, status: 'active' } : model
    ));
    
    // Atualizar registro de treinamento
    setTrainingHistory(trainingHistory.map(record => 
      record.modelId === modelId && record.status === 'in-progress' 
        ? { 
            ...record, 
            endTime: new Date().toISOString(),
            status: 'stopped',
            notes: record.notes + ' Treinamento interrompido manualmente.'
          } 
        : record
    ));
  };
  
  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Box sx={{ 
        mb: 4, 
        display: 'flex', 
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap'
      }}>
        <Box>
          <Typography variant="h4" component="h1" sx={{ fontWeight: 600, mb: 1 }}>
            Aprendizado de IA
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Treinamento e gerenciamento de modelos de inteligência artificial
          </Typography>
        </Box>
        
        <Box sx={{ display: 'flex', gap: 2, mt: { xs: 2, md: 0 } }}>
          <Button 
            variant="contained" 
            startIcon={<Refresh />}
          >
            Atualizar
          </Button>
        </Box>
      </Box>
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
                  Modelos Ativos
                </Typography>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  width: 40,
                  height: 40,
                  borderRadius: '50%',
                  bgcolor: alpha(colors.success.main, 0.1)
                }}>
                  <Psychology fontSize="small" sx={{ color: colors.success.main }} />
                </Box>
              </Box>
              <Typography 
                variant="h4" 
                component="div" 
                sx={{ 
                  fontWeight: 700, 
                  mb: 1,
                  color: colors.success.main
                }}
              >
                {aiModels.filter(m => m.status === 'active').length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {aiModels.filter(m => m.status === 'training').length} em treinamento
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
                  Precisão Média
                </Typography>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  width: 40,
                  height: 40,
                  borderRadius: '50%',
                  bgcolor: alpha(colors.primary.main, 0.1)
                }}>
                  <BarChart fontSize="small" sx={{ color: colors.primary.main }} />
                </Box>
              </Box>
              <Typography 
                variant="h4" 
                component="div" 
                sx={{ 
                  fontWeight: 700, 
                  mb: 1,
                  color: colors.primary.main
                }}
              >
                {(aiModels.reduce((acc, model) => acc + model.accuracy, 0) / aiModels.length).toFixed(1)}%
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Baseado em {aiModels.length} modelos
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
                  Treinamentos
                </Typography>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  width: 40,
                  height: 40,
                  borderRadius: '50%',
                  bgcolor: alpha(colors.warning.main, 0.1)
                }}>
                  <Autorenew fontSize="small" sx={{ color: colors.warning.main }} />
                </Box>
              </Box>
              <Typography 
                variant="h4" 
                component="div" 
                sx={{ 
                  fontWeight: 700, 
                  mb: 1,
                  color: colors.warning.main
                }}
              >
                {trainingHistory.length}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {trainingHistory.filter(t => t.status === 'in-progress').length} em andamento
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
                <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
                  Melhoria Média
                </Typography>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center',
                  width: 40,
                  height: 40,
                  borderRadius: '50%',
                  bgcolor: alpha(colors.info.main, 0.1)
                }}>
                  <TrendingUp fontSize="small" sx={{ color: colors.info.main }} />
                </Box>
              </Box>
              <Typography 
                variant="h4" 
                component="div" 
                sx={{ 
                  fontWeight: 700, 
                  mb: 1,
                  color: colors.info.main
                }}
              >
                {trainingHistory
                  .filter(t => t.status === 'completed' && t.finalAccuracy && t.initialAccuracy)
                  .reduce((acc, t) => acc + (t.finalAccuracy - t.initialAccuracy), 0) / 
                  trainingHistory.filter(t => t.status === 'completed' && t.finalAccuracy && t.initialAccuracy).length
                  > 0 
                    ? '+' + (trainingHistory
                        .filter(t => t.status === 'completed' && t.finalAccuracy && t.initialAccuracy)
                        .reduce((acc, t) => acc + (t.finalAccuracy - t.initialAccuracy), 0) / 
                        trainingHistory.filter(t => t.status === 'completed' && t.finalAccuracy && t.initialAccuracy).length
                      ).toFixed(1) + '%'
                    : '0%'
                }
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Nos últimos treinamentos
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
      
      <Paper sx={{ width: '100%', mb: 4 }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs 
            value={tabValue} 
            onChange={handleTabChange} 
            aria-label="ai learning tabs"
            variant="scrollable"
            scrollButtons="auto"
          >
            <Tab 
              icon={<Psychology />} 
              label="Modelos de IA" 
              {...a11yProps(0)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<History />} 
              label="Histórico de Treinamento" 
              {...a11yProps(1)} 
              sx={{ textTransform: 'none' }}
            />
            <Tab 
              icon={<Settings />} 
              label="Configurações de Aprendizado" 
              {...a11yProps(2)} 
              sx={{ textTransform: 'none' }}
            />
          </Tabs>
        </Box>
        
        <TabPanel value={tabValue} index={0}>
          <Grid container spacing={3}>
            {aiModels.map((model) => (
              <Grid item xs={12} md={6} lg={4} key={model.id}>
                <Card sx={{ height: '100%' }}>
                  <CardHeader
                    title={
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
                          {model.name}
                        </Typography>
                        <Tooltip title={model.type}>
                          <Box 
                            component="span" 
                            sx={{ 
                              px: 1.5, 
                              py: 0.5, 
                              borderRadius: '12px', 
                              fontSize: '0.75rem',
                              fontWeight: 600,
                              bgcolor: 
                                model.type === 'deep-learning' ? theme.palette.primary.main : 
                                model.type === 'ensemble' ? theme.palette.success.main : 
                                theme.palette.warning.main,
                              color: 
                                model.type === 'deep-learning' ? theme.palette.primary.contrastText : 
                                model.type === 'ensemble' ? theme.palette.success.contrastText : 
                                theme.palette.warning.contrastText
                            }}
                          >
                            {model.type === 'deep-learning' ? 'Deep Learning' : 
                             model.type === 'ensemble' ? 'Ensemble' : 
                             model.type === 'nlp' ? 'NLP' : model.type}
                          </Box>
                        </Tooltip>
                      </Box>
                    }
                    subheader={
                      <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                        <Box 
                          sx={{ 
                            width: 8, 
                            height: 8, 
                            borderRadius: '50%', 
                            bgcolor: 
                              model.status === 'active' ? colors.success.main : 
                              model.status === 'training' ? colors.warning.main : 
                              colors.error.main,
                            mr: 1
                          }} 
                        />
                        <Typography variant="body2" color="text.secondary">
                          {model.status === 'active' ? 'Ativo' : 
                           model.status === 'training' ? 'Em Treinamento' : 
                           'Inativo'}
                        </Typography>
                      </Box>
                    }
                    action={
                      <IconButton aria-label="settings" size="small">
                        <Settings fontSize="small" />
                      </IconButton>
                    }
                  />
                  <Divider />
                  <CardContent>
                    <Grid container spacing={2}>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">
                          Precisão:
                        </Typography>
                        <Typography 
                          variant="body1" 
                          sx={{ 
                            fontWeight: 600, 
                            color: 
                              model.accuracy >= 80 ? colors.success.main : 
                              model.accuracy >= 70 ? colors.warning.main : 
                              colors.error.main
                          }}
                        >
                          {model.accuracy.toFixed(1)}%
                        </Typography>
                      </Grid>
                      <Grid item xs={6}>
                        <Typography variant="body2" color="text.secondary">
                          Último Treino:
                        </Typography>
                        <Typography variant="body1">
                          {new Date(model.lastTrained).toLocaleDateString('pt-BR')}
                        </Typography>
                      </Grid>
                      <Grid item xs={12}>
                        <Typography variant="body2" color="text.secondary">
                          Mercados:
                        </Typography>
                        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 0.5 }}>
                          {model.markets.map((market) => (
                            <Box 
                              key={market}
                              sx={{ 
                                px: 1, 
                                py: 0.25, 
                                borderRadius: '4px', 
                                fontSize: '0.75rem',
                                bgcolor: 
                                  market === 'B3' ? alpha(colors.success.main, 0.1) : 
                                  market === 'S&P500' ? alpha(colors.primary.main, 0.1) : 
                                  alpha(colors.warning.main, 0.1),
                                color: 
                                  market === 'B3' ? colors.success.main : 
                                  market === 'S&P500' ? colors.primary.main : 
                                  colors.warning.main
                              }}
                            >
                              {market}
                            </Box>
                          ))}
                        </Box>
                      </Grid>
                      <Grid item xs={12}>
                        <Typography variant="body2" color="text.secondary">
                          Descrição:
                        </Typography>
                        <Typography variant="body2" sx={{ mt: 0.5 }}>
                          {model.description}
                        </Typography>
                      </Grid>
                    </Grid>
                    
                    {model.status === 'training' && (
                      <Box sx={{ mt: 2 }}>
                        <Typography variant="body2" color="text.secondary" gutterBottom>
                          Progresso do Treinamento
                        </Typography>
                        <LinearProgress 
                          sx={{ 
                            height: 6, 
                            borderRadius: 3,
                            mb: 1
                          }} 
                        />
                        <Typography variant="caption" color="text.secondary">
                          Treinamento em andamento... Isso pode levar alguns minutos.
                        </Typography>
                      </Box>
                    )}
                    
                    <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                      {model.status === 'training' ? (
                        <Button 
                          variant="outlined" 
                          size="small" 
                          color="error"
                          startIcon={<Stop />}
                          onClick={() => handleStopTraining(model.id)}
                        >
                          Parar Treinamento
                        </Button>
                      ) : (
                        <Button 
                          variant="contained" 
                          size="small"
                          startIcon={<PlayArrow />}
                          onClick={() => handleStartTraining(model.id)}
                        >
                          Iniciar Treinamento
                        </Button>
                      )}
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </TabPanel>
        
        <TabPanel value={tabValue} index={1}>
          <TableContainer>
            <Table sx={{ minWidth: 650 }} aria-label="histórico de treinamento">
              <TableHead>
                <TableRow>
                  <TableCell>Modelo</TableCell>
                  <TableCell>Início</TableCell>
                  <TableCell>Término</TableCell>
                  <TableCell>Épocas</TableCell>
                  <TableCell>Precisão Inicial</TableCell>
                  <TableCell>Precisão Final</TableCell>
                  <TableCell>Melhoria</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Ações</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {trainingHistory.map((record) => (
                  <TableRow
                    key={record.id}
                    sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                  >
                    <TableCell component="th" scope="row">
                      {record.modelName}
                    </TableCell>
                    <TableCell>
                      {new Date(record.startTime).toLocaleString('pt-BR', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </TableCell>
                    <TableCell>
                      {record.endTime 
                        ? new Date(record.endTime).toLocaleString('pt-BR', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })
                        : '-'
                      }
                    </TableCell>
                    <TableCell>{record.epochs}</TableCell>
                    <TableCell>{record.initialAccuracy.toFixed(1)}%</TableCell>
                    <TableCell>
                      {record.finalAccuracy 
                        ? record.finalAccuracy.toFixed(1) + '%'
                        : '-'
                      }
                    </TableCell>
                    <TableCell>
                      {record.finalAccuracy && record.initialAccuracy
                        ? (
                            <Typography 
                              sx={{ 
                                color: record.finalAccuracy - record.initialAccuracy > 0 
                                  ? colors.success.main 
                                  : colors.error.main,
                                fontWeight: 500,
                                display: 'flex',
                                alignItems: 'center'
                              }}
                            >
                              {record.finalAccuracy - record.initialAccuracy > 0 
                                ? <ArrowUpward fontSize="small" sx={{ mr: 0.5 }} />
                                : <ArrowDownward fontSize="small" sx={{ mr: 0.5 }} />
                              }
                              {(record.finalAccuracy - record.initialAccuracy > 0 ? '+' : '') + 
                                (record.finalAccuracy - record.initialAccuracy).toFixed(1) + '%'}
                            </Typography>
                          )
                        : '-'
                      }
                    </TableCell>
                    <TableCell>
                      <Box 
                        sx={{ 
                          display: 'inline-block',
                          px: 1, 
                          py: 0.5, 
                          borderRadius: '12px', 
                          fontSize: '0.75rem',
                          fontWeight: 600,
                          bgcolor: 
                            record.status === 'completed' ? alpha(colors.success.main, 0.1) : 
                            record.status === 'in-progress' ? alpha(colors.warning.main, 0.1) : 
                            alpha(colors.error.main, 0.1),
                          color: 
                            record.status === 'completed' ? colors.success.main : 
                            record.status === 'in-progress' ? colors.warning.main : 
                            colors.error.main
                        }}
                      >
                        {record.status === 'completed' ? 'Concluído' : 
                         record.status === 'in-progress' ? 'Em Andamento' : 
                         record.status === 'stopped' ? 'Interrompido' : 
                         'Falha'}
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Tooltip title="Ver Detalhes">
                        <IconButton size="small">
                          <Info fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </TabPanel>
        
        <TabPanel value={tabValue} index={2}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Card>
                <CardHeader title="Configurações de Dados" />
                <Divider />
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Fonte de Dados</InputLabel>
                        <Select
                          value={learningSettings.dataSource}
                          label="Fonte de Dados"
                          onChange={(e) => handleLearningSettingChange('dataSource', e.target.value)}
                        >
                          <MenuItem value="all">Todos os Mercados</MenuItem>
                          <MenuItem value="b3">B3 (Brasil)</MenuItem>
                          <MenuItem value="sp500">S&P 500 (EUA)</MenuItem>
                          <MenuItem value="crypto">Criptomoedas</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Timeframe</InputLabel>
                        <Select
                          value={learningSettings.timeframe}
                          label="Timeframe"
                          onChange={(e) => handleLearningSettingChange('timeframe', e.target.value)}
                        >
                          <MenuItem value="1m">1 minuto</MenuItem>
                          <MenuItem value="5m">5 minutos</MenuItem>
                          <MenuItem value="15m">15 minutos</MenuItem>
                          <MenuItem value="30m">30 minutos</MenuItem>
                          <MenuItem value="1h">1 hora</MenuItem>
                          <MenuItem value="4h">4 horas</MenuItem>
                          <MenuItem value="1d">Diário</MenuItem>
                          <MenuItem value="1w">Semanal</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={learningSettings.patternRecognition}
                            onChange={(e) => handleLearningSettingChange('patternRecognition', e.target.checked)}
                          />
                        }
                        label="Reconhecimento de Padrões"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={learningSettings.sentimentAnalysis}
                            onChange={(e) => handleLearningSettingChange('sentimentAnalysis', e.target.checked)}
                          />
                        }
                        label="Análise de Sentimento"
                      />
                    </Grid>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={learningSettings.fundamentalData}
                            onChange={(e) => handleLearningSettingChange('fundamentalData', e.target.checked)}
                          />
                        }
                        label="Dados Fundamentalistas"
                      />
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Card>
                <CardHeader title="Parâmetros de Treinamento" />
                <Divider />
                <CardContent>
                  <Grid container spacing={2}>
                    <Grid item xs={12}>
                      <Typography gutterBottom>
                        Taxa de Aprendizado
                      </Typography>
                      <Box sx={{ px: 1 }}>
                        <Slider
                          value={learningSettings.learningRate}
                          onChange={(e, newValue) => handleLearningSettingChange('learningRate', newValue)}
                          step={0.001}
                          min={0.001}
                          max={0.1}
                          valueLabelDisplay="auto"
                          valueLabelFormat={(value) => value.toFixed(3)}
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography gutterBottom>
                        Épocas de Treinamento
                      </Typography>
                      <Box sx={{ px: 1 }}>
                        <Slider
                          value={learningSettings.epochs}
                          onChange={(e, newValue) => handleLearningSettingChange('epochs', newValue)}
                          step={100}
                          min={100}
                          max={5000}
                          valueLabelDisplay="auto"
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography gutterBottom>
                        Tamanho do Lote (Batch Size)
                      </Typography>
                      <Box sx={{ px: 1 }}>
                        <Slider
                          value={learningSettings.batchSize}
                          onChange={(e, newValue) => handleLearningSettingChange('batchSize', newValue)}
                          step={8}
                          min={8}
                          max={128}
                          valueLabelDisplay="auto"
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12}>
                      <Typography gutterBottom>
                        Divisão de Validação
                      </Typography>
                      <Box sx={{ px: 1 }}>
                        <Slider
                          value={learningSettings.validationSplit}
                          onChange={(e, newValue) => handleLearningSettingChange('validationSplit', newValue)}
                          step={0.05}
                          min={0.1}
                          max={0.5}
                          valueLabelDisplay="auto"
                          valueLabelFormat={(value) => `${(value * 100).toFixed(0)}%`}
                        />
                      </Box>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Otimizador</InputLabel>
                        <Select
                          value={learningSettings.optimizer}
                          label="Otimizador"
                          onChange={(e) => handleLearningSettingChange('optimizer', e.target.value)}
                        >
                          <MenuItem value="adam">Adam</MenuItem>
                          <MenuItem value="sgd">SGD</MenuItem>
                          <MenuItem value="rmsprop">RMSprop</MenuItem>
                          <MenuItem value="adagrad">Adagrad</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </TabPanel>
      </Paper>
    </Container>
  );
};

export default AILearning;
