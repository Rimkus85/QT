# Documentação de Implementação - Sistema de Autenticação e Controle de Acesso

## Visão Geral

Este documento descreve as implementações realizadas no sistema de autenticação e controle de acesso do Quantum Trades Fase 2. As melhorias incluem persistência de sessão com localStorage, expiração automática de token, controle granular de acesso baseado em níveis de usuário e adaptação da interface para diferentes perfis.

## Componentes Implementados

### 1. Serviço de Autenticação Aprimorado (`AuthService.js`)

O serviço de autenticação foi completamente reescrito para incluir:

- **Persistência de sessão**: Utiliza localStorage para manter o usuário logado entre sessões
- **Expiração de token**: Implementa expiração automática após 8 horas de inatividade
- **Renovação de token**: Permite renovar o token antes da expiração
- **Níveis de acesso**: Suporte a diferentes níveis de usuário (Básico, Premium, Admin)
- **Verificação de permissões**: Método para verificar se o usuário tem permissão para acessar recursos específicos

#### Principais métodos:

```javascript
// Inicializa a sessão a partir do localStorage
initializeFromStorage()

// Salva os dados da sessão no localStorage
saveToStorage()

// Limpa os dados da sessão do localStorage
clearStorage()

// Configura temporizador para expiração automática do token
setupExpirationTimer()

// Gera um novo token com tempo de expiração
generateToken()

// Renova o token atual
async renewToken()

// Verifica se o usuário tem permissão para acessar determinado recurso
hasPermission(requiredLevel)
```

### 2. Componente de Controle de Acesso (`AccessControl.js`)

Componente React que controla a renderização condicional de elementos da interface com base no nível de acesso do usuário:

- **Renderização condicional**: Exibe ou oculta componentes com base no nível do usuário
- **Conteúdo alternativo**: Permite definir um fallback para usuários sem permissão
- **Ocultação completa**: Opção para não renderizar nada quando o usuário não tem permissão

#### Exemplo de uso:

```jsx
<AccessControl requiredLevel={ACCESS_LEVELS.PREMIUM} fallback={<UpgradeMessage />}>
  <PremiumFeature />
</AccessControl>
```

### 3. Estrutura de Perfis de Usuário (`UserProfileStructure.js`)

Define a estrutura de níveis de acesso e mapeamento de recursos:

- **Níveis de acesso**: Constantes para os diferentes níveis (Básico, Premium, Admin)
- **Detalhes dos níveis**: Descrições e recursos disponíveis para cada nível
- **Mapeamento de recursos**: Associação entre recursos do sistema e níveis mínimos necessários

#### Principais constantes e funções:

```javascript
// Níveis de acesso do sistema
ACCESS_LEVELS = { BASIC: 1, PREMIUM: 2, ADMIN: 3 }

// Descrições dos níveis de acesso
ACCESS_LEVEL_DETAILS

// Mapeamento de recursos para níveis de acesso
RESOURCE_ACCESS_MAP

// Verifica se um usuário tem acesso a um recurso específico
hasResourceAccess(userLevel, resourceKey)

// Obtém os recursos acessíveis para um determinado nível de usuário
getAccessibleResources(userLevel)
```

### 4. Proteção de Rotas (`ProtectedRoute.js`)

Componente para proteger rotas com base no nível de acesso do usuário:

- **Verificação de autenticação**: Redireciona para login se o usuário não estiver autenticado
- **Verificação de permissão**: Redireciona para página de acesso negado se o usuário não tiver permissão
- **Integração com React Router**: Compatível com React Router v6

#### Exemplo de uso:

```jsx
<Route 
  path="/premium-feature" 
  element={
    <ProtectedRoute requiredLevel={ACCESS_LEVELS.PREMIUM}>
      <PremiumFeaturePage />
    </ProtectedRoute>
  } 
/>
```

### 5. Páginas de Suporte

#### Página de Acesso Negado (`AccessDeniedPage.js`)

- Exibe informações sobre o nível de acesso necessário
- Mostra o nível atual do usuário
- Oferece opções para voltar, ir para o dashboard ou fazer upgrade

#### Página de Upgrade (`UpgradePage.js`)

- Apresenta os diferentes planos disponíveis
- Destaca o plano atual do usuário
- Permite fazer upgrade ou downgrade de plano

### 6. Adaptação da Interface

#### Menu com Controle de Acesso (`MenuWithAccessControl.js`)

- Exibe itens de menu de acordo com o nível do usuário
- Indica visualmente quais recursos requerem nível Premium ou Admin
- Mostra banner de upgrade para usuários do plano Básico

#### Layout Principal Atualizado (`MainLayout.js`)

- Integra o menu com controle de acesso
- Exibe informações do usuário logado
- Mantém a consistência visual em dispositivos móveis e desktop

## Fluxo de Autenticação

1. **Inicialização da aplicação**:
   - `AuthService` verifica localStorage para sessão existente
   - Se encontrar token válido, restaura a sessão
   - Configura temporizador para expiração automática

2. **Login do usuário**:
   - Valida credenciais
   - Gera token com tempo de expiração
   - Salva dados no localStorage
   - Configura temporizador para expiração

3. **Navegação protegida**:
   - `ProtectedRoute` verifica autenticação e permissão
   - Redireciona se necessário
   - Renderiza componente se usuário tem permissão

4. **Expiração de sessão**:
   - Temporizador executa logout automático
   - Remove dados do localStorage
   - Redireciona para página de login

5. **Logout manual**:
   - Remove dados do localStorage
   - Limpa estado de autenticação
   - Redireciona para página de login

## Testes Implementados

### Testes do Serviço de Autenticação (`AuthServiceTest.js`)

- Teste de login
- Verificação de autenticação
- Obtenção de usuário atual
- Verificação de permissão
- Renovação de token
- Logout
- Persistência após logout

### Testes do Componente de Controle de Acesso (`AccessControlTest.js`)

- Renderização com permissão
- Renderização com nível igual ao requerido
- Não renderização sem permissão
- Renderização de fallback
- Ocultação completa

## Considerações de Segurança

- **Armazenamento seguro**: Dados sensíveis não são armazenados no localStorage
- **Expiração automática**: Sessões expiram após período de inatividade
- **Verificação constante**: Permissões são verificadas em cada renderização
- **Proteção em camadas**: Controle tanto no frontend quanto nas rotas

## Próximos Passos

1. **Implementação no backend**: Integrar com sistema real de autenticação
2. **Autenticação em dois fatores**: Adicionar camada extra de segurança
3. **Auditoria de acessos**: Registrar tentativas de acesso não autorizado
4. **Personalização de permissões**: Permitir configuração granular por usuário
